﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employeencomp
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("Pathfront", "J.P Nagar");
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("enter your choice: 1.Add 2.Search 3.Remove 4.Show 5.Exit 6.Takeleave");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch(choice)
                {
                    case 1:
                        Console.WriteLine("enter employee name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("enter employee city:");
                        string city = Console.ReadLine();
                        Employee emp = new Employee(name, city);
                        c.AddEmployee(emp);
                        Console.WriteLine("employee id is:" + emp.PEmployeeid);
                        break;

                    case 2:
                        Console.WriteLine("enter employee id:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.SearchEmployee(ID);
                        if(obj != null)
                        {
                            Console.WriteLine(obj.PEmployeeid+" "+obj.PEmployeename+" "+obj.PEmployeecity);
                        }
                        else {
                            Console.WriteLine("employee not found");
                        }
                        break;

                    case 3:
                        Console.WriteLine("enter employee id:");
                        int eid = Convert.ToInt32(Console.ReadLine());
                        bool status = c.RemoveEmployee(eid);
                        if(status)
                        {
                            Console.WriteLine("employee removed");

                        }
                        else {
                            Console.WriteLine("employee not found");
                        }
                        break;
                    case 4:
                        c.ShowEmployess();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        Console.WriteLine("enter employee id:");
                        int newid = Convert.ToInt32(Console.ReadLine());
                        Employee eobj = c.SearchEmployee(newid);
                        Console.WriteLine("enter reason:");
                        string Reason = Console.ReadLine();
                        eobj.TakeLeave(Reason);
                        break;


                }
            }
        }
    }
}
