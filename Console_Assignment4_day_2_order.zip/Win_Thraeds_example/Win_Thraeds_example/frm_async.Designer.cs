﻿namespace Win_Thraeds_example
{
    partial class frm_async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_asyncsum = new System.Windows.Forms.Button();
            this.txt_number2 = new System.Windows.Forms.TextBox();
            this.txt_number1 = new System.Windows.Forms.TextBox();
            this.lbl_number2 = new System.Windows.Forms.Label();
            this.lbl_number1 = new System.Windows.Forms.Label();
            this.lst_msg = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_asyncsum
            // 
            this.btn_asyncsum.Location = new System.Drawing.Point(114, 177);
            this.btn_asyncsum.Name = "btn_asyncsum";
            this.btn_asyncsum.Size = new System.Drawing.Size(75, 23);
            this.btn_asyncsum.TabIndex = 10;
            this.btn_asyncsum.Text = "Async SUM";
            this.btn_asyncsum.UseVisualStyleBackColor = true;
            this.btn_asyncsum.Click += new System.EventHandler(this.btn_asyncsum_Click);
            // 
            // txt_number2
            // 
            this.txt_number2.Location = new System.Drawing.Point(225, 121);
            this.txt_number2.Name = "txt_number2";
            this.txt_number2.Size = new System.Drawing.Size(100, 20);
            this.txt_number2.TabIndex = 9;
            // 
            // txt_number1
            // 
            this.txt_number1.Location = new System.Drawing.Point(225, 85);
            this.txt_number1.Name = "txt_number1";
            this.txt_number1.Size = new System.Drawing.Size(100, 20);
            this.txt_number1.TabIndex = 8;
            // 
            // lbl_number2
            // 
            this.lbl_number2.AutoSize = true;
            this.lbl_number2.Location = new System.Drawing.Point(151, 128);
            this.lbl_number2.Name = "lbl_number2";
            this.lbl_number2.Size = new System.Drawing.Size(56, 13);
            this.lbl_number2.TabIndex = 7;
            this.lbl_number2.Text = "Number2 :";
            // 
            // lbl_number1
            // 
            this.lbl_number1.AutoSize = true;
            this.lbl_number1.Location = new System.Drawing.Point(151, 88);
            this.lbl_number1.Name = "lbl_number1";
            this.lbl_number1.Size = new System.Drawing.Size(56, 13);
            this.lbl_number1.TabIndex = 6;
            this.lbl_number1.Text = "Number1 :";
            // 
            // lst_msg
            // 
            this.lst_msg.FormattingEnabled = true;
            this.lst_msg.Location = new System.Drawing.Point(308, 193);
            this.lst_msg.Name = "lst_msg";
            this.lst_msg.Size = new System.Drawing.Size(120, 95);
            this.lst_msg.TabIndex = 11;
            // 
            // frm_async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 307);
            this.Controls.Add(this.lst_msg);
            this.Controls.Add(this.btn_asyncsum);
            this.Controls.Add(this.txt_number2);
            this.Controls.Add(this.txt_number1);
            this.Controls.Add(this.lbl_number2);
            this.Controls.Add(this.lbl_number1);
            this.Name = "frm_async";
            this.Text = "frm_async";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_asyncsum;
        private System.Windows.Forms.TextBox txt_number2;
        private System.Windows.Forms.TextBox txt_number1;
        private System.Windows.Forms.Label lbl_number2;
        private System.Windows.Forms.Label lbl_number1;
        private System.Windows.Forms.ListBox lst_msg;
    }
}