﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter orderid:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter item name:");
            string item = Console.ReadLine();
            Console.WriteLine("enter item price:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity:");
            int qty = Convert.ToInt32(Console.ReadLine());

            Order od = new Order(id, name, item, price, qty);
            int ordid = od.POrderid;
            string sname = od.PCustomername;
            string sitem = od.PItemname;
            int ordprice = od.PItemprice;
            int ordqty = od.PItemqty;
            Console.WriteLine(ordid + " " + sname + " " + sitem + " " + ordprice + " " + ordqty);
            int NewOr = od.GetOrderAmount();
            Console.WriteLine("order amount:" + NewOr);
            Console.ReadLine();






        }
    }
}

