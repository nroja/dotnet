﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Orderentry_application
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int ItemID;
        private int ItemQuantity;
        private int ItemPrice;
        private string DeliveryAddress;
        private string OrderCity;
        private string PaymentOption;
       
        public Order(int orderid,string customername,int itemid,int itemqty,int itemprice,string deliveryaddr,string ordercity,string payment)
        {
            this.OrderID = orderid;
            this.CustomerName = customername;
            this.ItemID = itemid;
            this.ItemQuantity = itemqty;
            this.ItemPrice = itemprice;
            this.DeliveryAddress = deliveryaddr;
            this.OrderCity = ordercity;
            this.PaymentOption = payment;
        }
         public int GetOrderValue()
         {
            return this.ItemPrice * this.ItemQuantity;
         }
    }
}
