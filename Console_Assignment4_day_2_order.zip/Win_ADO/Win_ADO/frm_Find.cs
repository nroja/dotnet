﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_Find : Form
    {
        public frm_Find()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employee emp = dal.Find(ID);
                if(emp!=null)
                {
                    txt_name.Text = emp.EmployeeName;
                    txt_city.Text = emp.EmployeeCity;
                    txt_password.Text = emp.EmployeePassword;
                    txt_doj.Text = emp.EmployeeDOJ.ToString();
                }
                else
                {
                    MessageBox.Show("not found");
                }


            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_id.Text == string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else if (txt_city.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                string city = txt_city.Text;
                string password = txt_password.Text;
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Update(ID, city, password);
                if (status)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("not found");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_id.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }

         

            }
        }
    }
}
