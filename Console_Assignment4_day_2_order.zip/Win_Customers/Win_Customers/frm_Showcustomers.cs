﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers
{
    public partial class frm_Showcustomers : Form
    {
        public frm_Showcustomers()
        {
            InitializeComponent();
        }

        private void lbl_employeecity_Click(object sender, EventArgs e)
        {

        }

        private void btn_searchall_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string key = txt_employeesearch.Text;
            List<Customers> list = dal.Searchcustomer(key);
            dg_customers.DataSource = list;
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string city = txt_employeecity.Text;
            List<Customers> list = dal.ShowCustomers(city);
            dg_customers.DataSource = list;
        }

        private void txt_employeesearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_search_Click(object sender, EventArgs e)
        {

        }

        private void txt_employeecity_TextChanged(object sender, EventArgs e)
        {

        }

        private void dg_employees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
