﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter employee id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter emplyee name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter employee salary:");
            int sal = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter type of employee:");
            string type = Console.ReadLine();

            Employee emp = null;
            if(type=="Employee")
            {
                emp = new Employee(id, name, sal);
            }
            else if(type=="Contract")
            {
                emp = new Employee_Contract(id, name, sal);
            }
            else if(type=="Training")
            {
                emp = new Employee_Training(id, name, sal);
            }
            if (emp != null)
            {
                string work = emp.GetWork();
                Console.WriteLine(work);
                Console.WriteLine("enter days:");
                int Days = Convert.ToInt32(Console.ReadLine());
                int monthsal = emp.GetSalary(Days);
                Console.WriteLine("salary:" + monthsal);
                Console.ReadLine();
            }
            
        }
    }
}
