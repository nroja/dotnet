﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee_Training:Employee
    {
    public Employee_Training(int employeeid,string employeename,int employeesalary)
          :base(employeeid,employeename,employeesalary)
          {

          }

          public override int GetSalary(int days)
          {
            return 10000;
          }
    }
}
