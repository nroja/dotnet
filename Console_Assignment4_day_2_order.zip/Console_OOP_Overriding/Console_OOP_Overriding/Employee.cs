﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee
    {
        private int EmployeeId;
        private string EmployeeName;
        private int EmployeeSalary;
        public Employee(int employeeid,string employeename,int employeesalary)
        {
            this.EmployeeId = employeeid;
            this.EmployeeName = employeename;
            this.EmployeeSalary = employeesalary;
        }

        public int PEmployeeid { get { return this.EmployeeId; } }
        public string PEmployeename { get { return this.EmployeeName; } }
        public int PEmployeesalary { get { return this.EmployeeSalary; } }
        
        public string GetWork()
        {
            return "developing .net application";
        }

        public virtual int GetSalary(int days)
        {
            int Bonus = 2000;
            int TDS = 1000;
            int Salary = (this.EmployeeSalary / 30 * days) + Bonus - TDS;
            return Salary;
        }
        
    }
}
