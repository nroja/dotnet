﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_Banking_Application
{
    class TransactionDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddTransaction(Transactions t1)
        {
            try
            {
                SqlCommand com_addtrans = new SqlCommand("proc_addtransaction", con);
                com_addtrans.Parameters.AddWithValue("@accountid", t1.AccountID);
                com_addtrans.Parameters.AddWithValue("@amount", t1.Amount);
                com_addtrans.Parameters.AddWithValue("@transtype", t1.TransactionType);
                com_addtrans.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_addtrans.Parameters.Add(retdata);
                con.Open();
                com_addtrans.ExecuteNonQuery();
                int id = Convert.ToInt32(retdata.Value);
                con.Close();
                return id;
            }
            finally
            {
              if(con.State==ConnectionState.Open)
              {
                    con.Close();
              }
            }
        }

        public List<Transactions> ShowTransaction(int ID)
        {
            try
            {
                SqlCommand com_showtrans = new SqlCommand("proc_showtransaction", con);
                com_showtrans.Parameters.AddWithValue("@id", ID);
                com_showtrans.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_showtrans.ExecuteReader();
                List<Transactions> translist = new List<Transactions>();
                while (dr.Read())
                {
                    Transactions obj = new Transactions();
                    obj.TransactionID = dr.GetInt32(0);
                    obj.AccountID = dr.GetInt32(1);
                    obj.Amount = dr.GetInt32(2);
                    obj.TransactionType = dr.GetString(3);
                    obj.TransactionDate = dr.GetDateTime(4);
                    translist.Add(obj);

                }
                con.Close();
                return translist;
            }

            finally
            {
              if(con.State==ConnectionState.Open)
              {
                    con.Close();
              }
            }
           


        }



    }
}
