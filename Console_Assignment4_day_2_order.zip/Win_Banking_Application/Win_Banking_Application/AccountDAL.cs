﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_Banking_Application
{
    class AccountDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddAccount(Accounts a1)
        {
            try
            {
                SqlCommand com_addaccount = new SqlCommand("proc_addaccount", con);
                com_addaccount.Parameters.AddWithValue("@customerid", a1.CustomerID);
                com_addaccount.Parameters.AddWithValue("@accountbalance", a1.AccountBalance);
                com_addaccount.Parameters.AddWithValue("@accounttype", a1.AccountType);
                com_addaccount.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_addaccount.Parameters.Add(retdata);
                con.Open();
                com_addaccount.ExecuteNonQuery();
                int id = Convert.ToInt32(retdata.Value);
                con.Close();
                return id;
            }
            finally
            {
              if(con.State==ConnectionState.Open)
              {
                    con.Close();
              }
            }

        } 

        public List<Accounts> ShowAccount(int ID)
        {
            try
            {
                SqlCommand com_showaccount = new SqlCommand("proc_showaccount", con);
                com_showaccount.Parameters.AddWithValue("@id", ID);
                com_showaccount.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_showaccount.ExecuteReader();
                List<Accounts> acclist = new List<Accounts>();
                while (dr.Read())
                {
                    Accounts obj = new Accounts();
                    obj.AccountID = dr.GetInt32(0);
                    obj.CustomerID = dr.GetInt32(1);
                    obj.AccountBalance = dr.GetInt32(2);
                    obj.AccountType = dr.GetString(3);
                    obj.AccountOpeningDate = dr.GetDateTime(4);
                    acclist.Add(obj);

                }
                con.Close();
                return acclist;
            }
            finally
            {
              if(con.State==ConnectionState.Open)
              {
                    con.Close();
              }
            }

        }

        public List<int> Getaccountid(int ID)
        {
            SqlCommand com_acc = new SqlCommand("proc_accountid", con);
            com_acc.Parameters.AddWithValue("@id", ID);
            com_acc.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_acc.ExecuteReader();
            List<int> acclist = new List<int>();
            while(dr.Read())
            {

                acclist.Add(dr.GetInt32(0));
           
            }
            con.Close();
            return acclist;



        }

        public int GetBalance(int aid)
        {
            SqlCommand com_balance = new SqlCommand("proc_getbalance", con);
            com_balance.Parameters.AddWithValue("@id", aid);
            com_balance.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_balance.Parameters.Add(retdata);
            con.Open();
            com_balance.ExecuteNonQuery();
            int id = Convert.ToInt32(retdata.Value);
            con.Close();
            return id;




        }



        
    }
}
