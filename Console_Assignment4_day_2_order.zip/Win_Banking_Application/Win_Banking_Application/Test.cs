﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Banking_Application
{
    class Test
    {
      public static int customerid { get; set; }
    }
}
