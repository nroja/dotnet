﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Lamba
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerName = "ABC", CustomerAge = 24, CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 2, CustomerName = "Ram", CustomerAge = 23, CustomerCity = "HYD" });
            custlist.Add(new Customer { CustomerID = 3, CustomerName = "Shivani", CustomerAge = 25, CustomerCity = "Pune" });
            custlist.Add(new Customer { CustomerID = 4, CustomerName = "Mahitha", CustomerAge = 24, CustomerCity = "HYD" });
            custlist.Add(new Customer { CustomerID = 5, CustomerName = "Rohith", CustomerAge = 22, CustomerCity = "BGL" });

            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "One plus 6T", ItemPrice = 35000 });
            ordlist.Add(new Order { OrderID = 1002, CustomerID = 1, ItemName = "TV", ItemPrice = 45000 });
            ordlist.Add(new Order { OrderID = 1003, CustomerID = 3, ItemName = "Laptop", ItemPrice = 37000 });
            ordlist.Add(new Order { OrderID = 1004, CustomerID = 2, ItemName = "One plus 6T", ItemPrice = 35000 });

            var data = custlist.Where((c) => c.CustomerCity == "BGL");
            foreach(var x in data)
            {
                Console.WriteLine(x.CustomerID + " " + x.CustomerName);
            }

            var count = custlist.Count((c) => c.CustomerCity == "BGL");
            Console.WriteLine(count);

            var obj = custlist.FirstOrDefault((c) => c.CustomerID == 1);
            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("not found");
            }

            var status = custlist.Exists((c) => c.CustomerID == 1);
            Console.WriteLine(status);

            var dataprojection = custlist.Where((c) => c.CustomerCity == "BGL").
            Select((s) => new { CID = s.CustomerID, CName = s.CustomerName });

            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.CID + " " + d.CName);
            }

            var dataorderby = custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => o.CustomerName).ThenByDescending((o1) => o1.CustomerCity);
            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }

            var groupdata = custlist.GroupBy((g) => g.CustomerCity).
            Select((s) => new {
             City = s.Key,
              Count = s.Count(),
               Avg = s.Average((a) => a.CustomerAge) });

               foreach(var x in groupdata)
               {
                Console.WriteLine(x.City + " " + x.Count + " " + x.Avg);
               }

            var joindata = custlist.Join(ordlist,
            (c) => c.CustomerID,
            (o) => o.CustomerID,
            (c, o) => new
            {
                CID = c.CustomerID,
                CName = c.CustomerName,
                OID = o.OrderID,
                IName = o.ItemName,
                IPrice = o.ItemPrice
            });

            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.IName + " " + j.IPrice);
            }
            Console.ReadLine();
            

        }
    }
}
