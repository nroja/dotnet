﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment4_day_2_order
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public int POrderID
        {
          get
          {
                return this.OrderID;
          }
          set
          {
                this.OrderID = value;
          }
        }

        public string PCustomerName
        {
        get{ return this.CustomerName; }
        set { this.CustomerName = value; }
        }

        public string PItemName
        {
        get { return this.ItemName; }
        set { this.ItemName = value; }
        }
        public int PItemPrice
        {
        get { return this.ItemPrice; }
        set { this.ItemPrice = value; }
        }
        public int PItemQuantity
        {
        get { return this.ItemQuantity; }
        set { this.ItemQuantity = value; }
        }
        private static int Count = 20;
        public Order(string customername,string itemname,int itemprice,int itemqty)
        {
            Order.Count++;
            this.OrderID = Order.Count;
            this.CustomerName = customername;
            this.ItemName = itemname;
            this.ItemPrice = itemprice;
            this.ItemQuantity = itemqty;

        }

        public int GetOrderAmount()
        {
            return this.ItemQuantity * this.ItemPrice;
        }

      
    }
}
