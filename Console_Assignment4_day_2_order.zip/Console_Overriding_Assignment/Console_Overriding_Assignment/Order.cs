﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding_Assignment
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int ItemQty;
        private int ItemPrice;
        private static int Count = 100;
        public Order(string customername,int itemqty,int itemprice)
        {
            Order.Count++;

            this.OrderID = Order.Count;
            this.CustomerName = customername;
            this.ItemQty = itemqty;
            this.ItemPrice = itemprice;
        }

        public int POrderid { get { return this.OrderID; } }
        public string PCustomername { get { return this.CustomerName; } }
        public int PItemqty { get { return this.ItemQty; } }
        public int PItemprice { get { return this.ItemPrice; } }

        public virtual int GetOrderValue()
        {
            return this.ItemPrice * this.ItemQty;
        }
    }
}
