﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Structure
{
    struct Book
    {
        private int ID;
        private string Name;
        public Book(int id, string name)
        {
            this.ID = id;
            this.Name = name;
        }

        public int Pid { get { return this.ID; } }
        public string Pname
        {
            get { return this.Name; }
            set { this.Name = value; }
        }
    }
}
