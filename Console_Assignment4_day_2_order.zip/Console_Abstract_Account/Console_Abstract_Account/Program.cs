﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter account id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter the account balance:");
            int bal = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter account type:");
            string type = Console.ReadLine();
            Account obj = null;
            if(type == "Savings")
            {
                obj = new Saving(id, name, bal);
            }
            else if(type == "Current")
            {
                obj = new Current(id, name, bal);

            }
            if(type != null)
            {
                obj.StopPayment();
                obj.BlockAccount();
                int accbal = obj.GetBalance();
                Console.WriteLine("balance is:" + accbal);
                Console.WriteLine("enter the amount to deposit:");
                int amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(amt);
                accbal = obj.GetBalance();
                Console.WriteLine("balance is:" + accbal);
                Console.WriteLine("enter amount to withdraw:");
                amt = Convert.ToInt32(Console.ReadLine());
                obj.Withdraw(amt);
                accbal = obj.GetBalance();
                Console.WriteLine("balance is:" + accbal);

            }
            Console.ReadLine();
        }
    }
}
