﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    abstract class Account
    {
        protected int AccountID;
        protected string CustomerName;
        protected int AccountBalance;

        public Account(int accid,string customername,int accbal)
        {
            this.AccountID = accid;
            this.CustomerName = customername;
            this.AccountBalance = accbal;
            Console.WriteLine("account constructor");
        }
        public int PAccountid { get { return this.AccountID; } }
        public string PCustomername { get { return this.CustomerName; } }
        public int PAccountbalance { get { return this.AccountBalance; } }

        public void StopPayment()
        {
            Console.WriteLine("stop payment called");
        }

        public void BlockAccount()
        {
            Console.WriteLine("block account called");
        }
        public int GetBalance()
        {
            return this.AccountBalance;
        }
        public abstract void Deposit(int Amt);
        public abstract void Withdraw(int Amt);
    }
}
