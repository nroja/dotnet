﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Account
{
    class Saving :Account
    {
    public Saving(int accountid,string customername,int accountbalance)
        :base(accountid,customername,accountbalance)
        {
            Console.WriteLine("savings account called");
        }

        public override void Deposit(int Amt)
        {
           this.AccountBalance+=Amt+100;
        }

        public override void Withdraw(int Amt)
        {
           this.AccountBalance-=Amt+100;
        }
    }
}
