﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("E1", "Ajay");
            names.Add("E2", "Karthik");
            names.Add("E3", "Rishi");
            names.Add("E4", "John");

            foreach(KeyValuePair<string,string> s in names)
            {
                Console.WriteLine(s.Key + " " + s.Value);
            }
            foreach(string k in names.Keys)
            {
                Console.WriteLine(k);
            }
            foreach(string j in names.Values)
            {
                Console.WriteLine(j);
            }
            string name = names["E1"];
            Console.WriteLine(name);
            Console.ReadLine();
        }
    }
}
