﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using X=Console_Enum_Vardynamic_Using1;
using static Console_Enum_Vardynamic_Using1.Test;

namespace Console_Enum_Vardynamic_Using
{
    class Program
    {
        static void Main(string[] args)
        {
            var i = 100;
            var obj = new X.Test();
            dynamic d = 100;
            d.call();

            X.Test t1 = new X.Test();
            t1.MakePayment(PaymentType.Netbanking);
            call();
        }
    }
}
