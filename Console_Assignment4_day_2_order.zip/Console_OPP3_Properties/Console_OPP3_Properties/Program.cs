﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OPP3_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
       
            Console.WriteLine("enter student name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter student marks:");
            int marks = Convert.ToInt32(Console.ReadLine());

            Student std = new Student( name, marks);
            int sid = std.PStudentID;
            string sname = std.PStudentName;
            int smarks = std.PStudentMarks;
            Student s1 = new Student("ABC", 76);
            Console.WriteLine(s1.PStudentID);
            Console.WriteLine(sid + " " + sname+" "+smarks);
            std.PStudentMarks = -15;
            Console.WriteLine(std.PStudentMarks);
            std.PStudentMarks = 89;
            Console.WriteLine(std.PStudentMarks);
            Console.ReadLine();
        }
    }
}
