﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_day1basics1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = new num[5];
            num[0] = 10;
            num[1] = 12;
            num[2] = 13;
            num[3] = 14;
            num[4] = 15;
            for(int c=0;c<num.Length;c++)
            {
                Console.WriteLine(c);
            }

            int x = 0;
            while(x<10)
            {
                Console.WriteLine(x);
                x++;
            }

            for(int c=0;c<10;c++)
            {
                Console.WriteLine(c);
            }
            foreach(int n in num)
            {
                Console.WriteLine(n);
            }

            bool flag = true;
            while(flag)
            {
                Console.WriteLine(flag);
                flag = false;
            }

            int opt = 1;
            switch(opt)
            {
                case 1: 
                         Console.WriteLine("One");
                         break;
                case 2:
                         Console.WriteLine("Two");
                         break;
                case 2:
                         Console.WriteLine("Three");
                         break;
                default:
                        Console.WriteLine("invalid");
                         break;



            }

            Console.WriteLine("enter item name\n");
            string item1 = Console.ReadLine();
            Console.WriteLine("enter item quantity\n");
            int qty = Convert.ToInt32(Console.ReadLine());
            if(qty<1)
            {
                Console.WriteLine("invalid");
            }
            else
            {
                Console.WriteLine("invalid");
            }

        }
    }
}
