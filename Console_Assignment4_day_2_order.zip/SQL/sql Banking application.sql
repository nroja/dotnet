create database BankingDB

create table tbl_Customers
(
customerid int identity(1,1) primary key,
customername varchar(50),
customeremail varchar(50),
customermobile varchar(50),
customergender varchar(50),
customerpassword varchar(50)
)
select * from tbl_Customers

create table tbl_Accounts
(
accountid int identity(100,1) primary key,
customerid int not null foreign key references tbl_customers(customerid),
accountbalance int,
accounttype varchar(50),
accountopeningdate datetime
)
select * from tbl_Accounts

create table tbl_Transactions
(
transid int identity(1000,1) primary key,
accountid int foreign key references tbl_accounts(accountid),
amount int,
transtype varchar(50),
transdate datetime
)

select * from tbl_Customers

create proc proc_addcustomer(@name varchar(50),@email varchar(50),@mobile varchar(50),
@gender varchar(50),@password varchar(50))
as
insert tbl_Customers values(@name,@email,@mobile,@gender,@password)
return @@identity

create proc proc_showcustomer(@id int)
as
select * from tbl_Customers where customerid=@id

create proc proc_customerlogin(@id int,@password varchar(50))
as
declare @count int
select @count=count(*) from tbl_Customers where 
customerid=@id and customerpassword=@password
return @count

alter proc proc_addaccount(@customerid int,@accountbalance int,@accounttype varchar(50))
as
insert tbl_Accounts values(@customerid,@accountbalance,@accounttype,GETDATE())
return @@identity

alter proc proc_showaccount(@id int)
as
select * from tbl_Accounts where customerid=@id

create proc proc_addtransaction(@accountid int,@amount int,@transtype varchar(50))
as
insert tbl_Transactions values(@accountid,@amount,@transtype,GETDATE())
return @@identity

create proc proc_showtransaction(@id int)
as
select * from tbl_Transactions where accountid=@id

alter trigger trg_updatebalance
on tbl_transactions
for insert 
as
begin
declare @accountid int
declare @type varchar(50)
declare @amount int
select @accountid=accountid,@amount=amount,@type=transtype from inserted
if(@type='Deposit')
begin
update tbl_Accounts set accountbalance=accountbalance+@amount where accountid=@accountid
end
else 
update tbl_Accounts set accountbalance=accountbalance-@amount where accountid=@accountid
end

select * from tbl_transactions
select * from tbl_Customers
select * from tbl_Accounts

create proc proc_accountid(@id int)
as
select accountid from tbl_Accounts where customerid=@id

alter proc proc_getbalance(@id int)
as
declare @bal int
select @bal=accountbalance from tbl_Accounts where accountid=@id
return @bal
