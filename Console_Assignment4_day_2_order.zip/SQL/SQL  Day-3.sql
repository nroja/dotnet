declare @count int=0;
set @count=100;
select @count=COUNT(*) from tbl_employees
if(@count>0)
begin
--insert
end
else
begin
--update
end
select @count;

select * from tbl_employees
declare @count int=0;
while(@count<10)
begin
select @count;
set @count=@count+1;
end

alter proc sp_employees
as
select * from tbl_employees order by employeeSalary desc

exec sp_employees

create proc sp_employees_city(@city varchar(100))
as
select * from tbl_employees where employeeCity=@city

exec sp_employees_city 'Hyderabad'

select * from tbl_Accounts  

create proc sp_add_account(@name varchar(100),@balance int)
as
if(@balance>=1000)
begin
insert tbl_Accounts values(@name,@balance)
return @@identity
end 
else
begin
return 0
end

declare @r int
exec @r=sp_add_account 'abc',200
select @r

create proc sp_account_balance(@accountid int)
as
declare @balance int
select @balance=accountbalance from tbl_Accounts where AccountID=@accountid;
return @balance

declare @bal int
exec @bal=sp_account_balance 1001
select @bal

select * from tbl_CustomersInfo

create proc sp_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_CustomersInfo
where Customerid=@id and Customerpassword=@password
return @count

declare @c int
exec @c=sp_login 101,'bhagya123'
select @c

select * from tbl_employees

create proc sp_employeedetails(@id int,@name varchar(100) output,@city varchar(100) output)
as
select @name=employeename,@city=employeecity from tbl_employees where employeeID=@id

declare @ename varchar(100)
declare @ecity varchar(100)
exec sp_employeedetails 101,@ename output,@ecity output
select @ename,@ecity

create table tbl_students
(
studentid int,
studentname varchar(50),
studentcity varchar(50)
)

create Trigger trg_add_student
on tbl_students
for insert
as
begin
select 'Trigger fired'
end

insert tbl_students values(2,'B','Chennai')


select * from tbl_students

alter Trigger trg_add_student
on tbl_students
for insert
as
begin
select * from inserted
select 'Trigger fired'
end

insert tbl_students values(5,'C','Chennai')

create table tbl_stock
(
Itemid int primary key,
Qty int
)

insert tbl_stock values(1,100)
insert tbl_stock values(2,80)
insert tbl_stock values(3,60)
insert tbl_stock values(4,100)

create table tbl_Order
(
Orderid int identity(100,1) primary key,
Itemid int not null foreign key references tbl_stock(itemid),
Qty int ,
Price int check(price > 0)
)

insert tbl_order values(2,5,300)
insert tbl_Order values(1,15,500)
insert tbl_Order values(3,10,600)

select * from tbl_stock
select * from tbl_Order

alter Trigger trg_update_stock
on tbl_order
for insert
 as
  begin

  declare @itemid int
  declare @qty int 
  select @itemid=itemid,@qty=qty from inserted
  update tbl_stock set qty=qty-@qty where itemid=@itemid
  end

  insert tbl_order values(4,15,100)

  select * from tbl_order

  select * from tbl_stock

  select * from tbl_employees

  alter view V_Employees_BGL
  with encryption,schemabinding
  as
  select employeeid,employeename,employeeSalary,employeeCity  from dbo.tbl_employees where employeeCity='Banglore'
  with check option

  drop table tbl_employees


  sp_helptext V_employees_BGL

  select * from V_Employees_BGL

  insert V_Employees_BGL values(102,'bhagya','Banglore',30000)
  insert V_Employees_BGL values(103,'hema','mumbai',23000)

  select * from V_Employees_BGL where employeeSalary >15000

  select * from tbl_employees

  create table tbl_t1
  (
  code int,
  name varchar(50)
  )


  create table tbl_t2
  (
  code int,
  city varchar(50)
  )
  insert tbl_t1 values(1,'A')
  insert tbl_t2 values(1,'BGL')

  select * from tbl_t1
  select * from tbl_t2

  create view v_data
  as
  select tbl_t1.code,tbl_t1.name,tbl_t2.city from tbl_t1 join tbl_t2 on tbl_t1.code=tbl_t2.code

  select * from v_data

  insert v_data values(2,'XYZ','Pune')

create trigger trg_view
on v_data
 instead of insert
 as
 begin
 declare @code int
 declare @name varchar(100)
 declare @city varchar(100)
 select @code=code,@name=name,@city=city from inserted
 insert tbl_t1 values(@code,@name)
 insert tbl_t2 values(@code,@city)
 end

 create table tbl_employeesinfo
 (
 employeeid int identity(1,1),
 employeename varchar(50),
 employeecity varchar(50)
 )

 declare @c int =0;
 while(@c<50000)
 begin
 insert tbl_employeesinfo values('ABCD','HYD');
 set @c=@c+1;
 end

 select * from tbl_employeesinfo where employeeid=49999

 create clustered index idx
 on tbl_employeesinfo(employeeid)

 select * from tbl_employees

 begin tran tr1

 insert tbl_employees values(101,'ABC','BGL',20000)

 select * from tbl_employees

insert tbl_employees values(103,'XYZ','pune',17000)

rollback tran


commit tran













