create database pathfrontDB2

create table tbl_customers
(
customerid int identity(1000,1) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customeremail varchar(100) not null unique,
customermobileno varchar(15) not null unique
)

insert tbl_customers values('Rohith','Pune','rohith@gmail.com','9498662319')
insert tbl_customers values('Manisha','Chennai','manisha@gmail.com','9855238890')
insert tbl_customers values('Bhagya','Banglore','bhagya@gmail.com','8106769123')
insert tbl_customers values('Swetha','Hyderabad','swetha@gmail.com','8703223390')
insert tbl_customers values('Shivani','Hyderabad','shiv@gmail.com','6367004590')

select * from tbl_customers

create table tbl_items
(
ItemID int identity(1,1) primary key,
ItemName varchar(100) not null,
ItemPrice int check(ItemPrice > 0)
)

insert tbl_items values('Laptop',35000)
insert tbl_items values('Mobile',10000)
insert tbl_items values('Desktop',15000)
insert tbl_items values('Watch',6000)
insert tbl_items values('Powerbank',3000)

select * from tbl_items

create table tbl_invoices
(
invoiceId int identity(10000,1) primary key,
customerid int not null foreign key references tbl_customers(customerid),
invoicecity varchar(100) not null,
invoicedate datetime not null,
invoiceaddress varchar(100)
)

insert tbl_invoices values(1001,'Banglore',GETDATE(),'Btm layout')
insert tbl_invoices values(1000,'Hyderabad',getdate(),'JP nagar')
insert tbl_invoices values(1002,'Hyderabd',getdate(),'Hanuman nagar')
insert tbl_invoices values(1003,'Pune',GETDATE(),'shammerpet')
insert tbl_invoices values(1004,'Chennai',GETDATE(),'gourang')



select * from tbl_invoices

create table tbl_invoiceitems
(
invoiceid int not null foreign key references tbl_invoices(invoiceid),
itemid int not null foreign key references tbl_items(itemid),
itemqty int check(itemqty > 0),
itemprice int check(itemprice > 0),
primary key (invoiceid,itemid)
)

insert tbl_invoiceitems values(10002,2,1,8000)
insert tbl_invoiceitems values(10002,3,2,9000)
insert tbl_invoiceitems values(10000,2,2,10000)
insert tbl_invoiceitems values(10000,4,1,33000)
insert tbl_invoiceitems values(10005,4,3,32000)
insert tbl_invoiceitems values(10005,3,1,17000)
insert tbl_invoiceitems values(10003,5,2,1500)
insert tbl_invoiceitems values(10000,5,1,2500)
insert tbl_invoiceitems values(10000,1,2,2600)
insert tbl_invoiceitems values(10006,3,1,12000)

select * from tbl_customers
select * from tbl_items
select * from tbl_invoices
select * from tbl_invoiceitems

select * from tbl_customers where customerid in (
select customerid from tbl_invoices
)

select * from tbl_customers where customerid not in (
select customerid from tbl_invoices
)

select * from tbl_items where itemid in (
select ItemID from tbl_invoiceitems
)

select itemname from tbl_items where ItemID in (
select ItemID from tbl_invoiceitems
)

select * from tbl_customers where customerid in (
select top 1 customerid from tbl_invoices order by invoicedate desc
)

create table tbl_employees
(
employeeid int identity(1,1) primary key,
employeename varchar(100) not null,
employeesalary int not null,
employeedpt varchar(100),
managerid int foreign key references tbl_employees(employeeid)
)

insert tbl_employees values('John',20000,'HR',null)
insert tbl_employees values('Rosy',16000,'HR',1)
insert tbl_employees values('XYZ',20000,'IT',null)
insert tbl_employees values('ABC',18000,'IT',3)
select * from tbl_employees

select top 1 * from tbl_employees where employeeid not in
(
select top 1 with ties employeeid from tbl_employees order by employeesalary desc
)order by employeesalary desc

select top 1 * from tbl_employees where employeeid in
( 
select top 2 employeeid from tbl_employees order by employeesalary desc)
order by employeesalary asc

select * from tbl_employees e1 where e1.employeesalary>
(select AVG(e2.employeesalary) from tbl_employees e2
where e2.employeedpt=e1.employeedpt)

select * from tbl_customers
select * from tbl_invoices

select tbl_customers.customerid,tbl_customers.customername,tbl_invoices.invoiceId,
tbl_invoices.invoicedate from tbl_customers join tbl_invoices
on
tbl_customers.customerid=tbl_invoices.customerid

select tbl_invoices.invoiceid,tbl_invoices.customerid,tbl_invoices.invoicecity,
tbl_invoiceitems.itemid,tbl_invoiceitems.itemqty,tbl_items.ItemID from tbl_invoices join tbl_invoiceitems
on
tbl_invoices.invoiceId=tbl_invoiceitems.invoiceid
join tbl_items
on
tbl_invoiceitems.itemid=tbl_items.ItemID

select tbl_customers.customerid,tbl_customers.customername,tbl_invoices.invoiceid,
tbl_invoices.invoicedate from tbl_customers left outer join tbl_invoices
on
tbl_customers.customerid=tbl_invoices.customerid

select * from tbl_customers cross join tbl_invoices

select * from tbl_employees

select e.employeeid,e.employeename,e.employeesalary,e.managerid,m.employeename
from tbl_employees e join tbl_employees m
on
e.managerid=m.employeeid

select e.employeeid,e.employeename,e.employeesalary,e.managerid,m.employeename
from tbl_employees e join tbl_employees m
on
e.managerid=m.employeeid