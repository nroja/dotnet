﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Implement_Interface_Concept
{
    class Account
    {
     public void GetEmployee(IAccountEmp obj)
     {
            int accsal = obj.GetEmployeeSalary();
            Console.WriteLine("employee salary:" + accsal);
            int accn = obj.GetEmployeeAccountNo();
            Console.WriteLine("account number is:" + accn);
            int ID = obj.GetEmployeeID();
            Console.WriteLine("employee id is:" + ID);
     }
    }
}
