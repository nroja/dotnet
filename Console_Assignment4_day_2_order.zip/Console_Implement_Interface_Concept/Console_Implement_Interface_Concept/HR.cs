﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Implement_Interface_Concept
{
    class HR
    {
        public void GetEmployee(IHREmp obj)
         {
            string addr = obj.GetEmployeeAddress();
            Console.WriteLine("employee address is:" + addr);
            int sal = obj.GetEmployeeSalary();
            Console.WriteLine("employee salary is:" + sal);
            int id = obj.GetEmployeeID();
            Console.WriteLine("employee id :" + id);

         }
    }
}
