﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Implement_Interface_Concept
{
    class Manager
    {
     public void GetEmployee(IManagerEmp obj)
     {
            int mid = obj.GetEmployeeID();
            Console.WriteLine("employee id :" + mid);
            int exp = obj.GetEmployeeExp();
            Console.WriteLine("employee experience :" + exp);
            string pro = obj.GetEmployeeProjectDetails();
            Console.WriteLine("project details are:" + pro);
     }
    }
}
