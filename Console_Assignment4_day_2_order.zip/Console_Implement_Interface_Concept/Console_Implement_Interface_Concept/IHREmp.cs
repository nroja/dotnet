﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Implement_Interface_Concept
{
    interface IHREmp
    {

        string GetEmployeeAddress();
        int GetEmployeeSalary();
        int GetEmployeeID();

    }
}
