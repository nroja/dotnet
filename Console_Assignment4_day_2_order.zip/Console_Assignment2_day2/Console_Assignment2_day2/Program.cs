﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment2_day2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter orderId:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter itemname:");
            string item = Console.ReadLine();
            Console.WriteLine("enter itemprice:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter itemquantity:");
            int qty = Convert.ToInt32(Console.ReadLine());


            Order obj = new Order(id,name,item,price,qty);
            int NewAmount = obj.GetOrderAmount();
            Console.WriteLine("orderAmount:" + NewAmount);

            string Newdetails=obj.Getdetails();
            Console.WriteLine("getdetails:" + Newdetails);
            Console.ReadLine();


        }
       

    }
}
