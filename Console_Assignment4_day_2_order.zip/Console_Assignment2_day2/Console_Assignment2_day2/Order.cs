﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment2_day2
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQty;

        public Order(int orderid,string customername,string itemname,int itemprice,int itemqty)
        {
            this.OrderID = orderid;
            this.CustomerName = customername;
            this.ItemName = itemname;
            this.ItemPrice = itemprice;
            this.ItemQty = itemqty;
        }

        public int GetOrderAmount()
        {
            return   ItemPrice * ItemQty;
        }

        public string Getdetails()
        {
           return this.OrderID + " " + this.CustomerName + " " + this.ItemName + " " + this.ItemPrice + " " + ItemQty;
        }
    }
}
