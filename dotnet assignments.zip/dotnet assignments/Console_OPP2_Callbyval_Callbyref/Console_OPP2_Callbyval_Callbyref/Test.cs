﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OPP2_Callbyval_Callbyref
{
    class Test
    {
      public void Call(out int Amt)
      {
            //Console.WriteLine(Amt);
            Amt = 1000;
      }

      public void CallArray( params int[]  marks)
      {
       foreach(int n in marks)
       {
                Console.WriteLine(n);
       }
      }
      public int GetOrderValue(int ItemPrice,int ItemQty=1)
      {
            return ItemQty * ItemPrice;
      }
    }
}
