﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OPP2_Callbyval_Callbyref
{
    class Program
    {
        static void Main(string[] args)
        {
            XYZ obj1 = new XYZ();
            obj1.Call();
            obj1.GetData();
            int[] marks = new int[3];
            marks[0] = 12;
            marks[1] = 15;
            marks[2] = 18; 



            Test obj = new Test();
            obj.CallArray(15,19,23);
            int OrderAmt = obj.GetOrderValue(ItemQty:2,ItemPrice:2000);
            Console.WriteLine(OrderAmt);
            int x;
            obj.Call(out x);
            Console.WriteLine(x);
            Console.ReadLine();
        }
    }
}
