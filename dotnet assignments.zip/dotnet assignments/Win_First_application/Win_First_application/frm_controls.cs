﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_application
{
    public partial class frm_controls : Form
    {
        public frm_controls()
        {
            InitializeComponent();
        }

        private void frm_controls_Load(object sender, EventArgs e)
        {
            lst_cities.Items.Add("Pune");
            lst_cities.Items.Add("Hyderabad");
            lst_cities.Items.Add("Chennai");

            cmb_cities.Items.Add("CSE");
            cmb_cities.Items.Add("ECE");
            cmb_cities.Items.Add("EEE");

            
        }

        private void btn_save_Click(object sender, EventArgs e)
        {

        if(rdb_male.Checked == false && rdb_female.Checked == false)
        {
                MessageBox.Show("select your gender");
        }
        else
        {
                string gender = string.Empty;
                if(rdb_male.Checked)
                {
                    gender = "male";
                }
                else
                {
                    gender = "female";
                }
                MessageBox.Show("gender is:" + gender);
        }
            bool staus = chk_readme.Checked;
            if(staus)
            {
                MessageBox.Show("it is checked");
            }
            else
            {
                MessageBox.Show("not checked");
            }
            if(lst_cities.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else 
            {
                string city = lst_cities.Text;
                MessageBox.Show(city);
            }
        }
    }
}
