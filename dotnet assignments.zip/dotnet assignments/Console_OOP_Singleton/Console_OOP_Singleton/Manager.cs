﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Singleton
{
    class Manager
    {
        private int ManagerID;
        private string ManagerName;

        public int PManagerid { get { return this.ManagerID; } }
        public string PManagername { get { return this.ManagerName; } }

        private Manager(int managerid,string managername)
        {
            this.ManagerID = managerid;
            this.ManagerName = managername;
        }
        static Manager m;
        public static Manager GetManager()
        {
            if (m == null)
            {
                m = new Manager(1001, "ABC");
            }
            return m;
        }
    }
}
