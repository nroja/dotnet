﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Test
    {
        public delegate void del(string str);

        public void call1(string str)
        {
            Console.WriteLine("call1:" + str);
        }

        public void call2(string str)
        {
            Console.WriteLine("call2:" + str);
        }


    }
}
