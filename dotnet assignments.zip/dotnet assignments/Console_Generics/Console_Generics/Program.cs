﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generics
{
    class Program
    { 
        static void Main(string[] args)
        {

        List<int> marks = new List<int>();
        marks.Add(100);
        marks.Add(200);
        int m = marks[0];
        foreach(int n in marks)
        {
            Console.WriteLine(n);
        }
            List<string> names = new List<string>();
            names.Add("Roja");
            names.Add("Shivani");
            foreach(string j in names)
            {
                Console.WriteLine(j);
            }
            Dictionary<int, string> nameswithkeys = new Dictionary<int, string>();
            nameswithkeys.Add(1001, "Roja");
            nameswithkeys.Add(1002, "ABC");
            string s1 = nameswithkeys[1001];
            Console.WriteLine(s1);

            Test t = new Test();
            int x = t.GetDetails<int>(1000);
            string str = t.GetDetails<string>("Hello");
            Console.WriteLine(x);
            Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
