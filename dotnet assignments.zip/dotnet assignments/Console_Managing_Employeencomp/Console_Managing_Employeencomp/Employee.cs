﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employeencomp
{
    class Employee
    {

        public delegate void delleave(int ID, string Reason);
        public event delleave evtleave;
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private static int Count = 100;
        public Employee(string employeename,string employeecity)
        {
            Employee.Count++;
            this.EmployeeID = Employee.Count;
            this.EmployeeName = employeename;
            this.EmployeeCity = employeecity;
        }
        public int PEmployeeid { get { return this.EmployeeID; } }
        public string PEmployeename { get { return this.EmployeeName; } }
        public string PEmployeecity { get { return this.EmployeeCity; } }

      public void TakeLeave(string Reason)
      {
            if(this.evtleave!=null)
            {
                this.evtleave(this.EmployeeID, Reason);
            }

            Console.WriteLine("employee on leave:" + this.EmployeeID + ",the reason is:" + Reason);
      }
    }
}
