﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the AccountId:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Customer Name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter balance:");
            int balance = Convert.ToInt32(Console.ReadLine());

            Account obj = new Account(id, name, balance);
            int NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance:" + NewBalance);

            Console.WriteLine("enter amount to withdraw:");
            int Amt = Convert.ToInt32(Console.ReadLine());

            obj.Withdraw(Amt);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance:" + NewBalance);

            Console.WriteLine("enter amount to deposit:");
            Amt = Convert.ToInt32(Console.ReadLine());
            obj.Deposit(Amt);

            NewBalance = obj.GetBalance();
            Console.WriteLine("Account Balance:" + NewBalance);



            //Console.WriteLine("enter customer ID:");
            //int id = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("enter customer Name:");
            //string name = Console.ReadLine();
            //Console.WriteLine("enter customer City:");
            //string city = Console.ReadLine();

            //Customer obj = new Customer(id, name, city);

            //string details = obj.GetDetails();
            //Console.WriteLine(details);
            Console.ReadLine();

        }
    }
}
