﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_library
{
   public class test
    {
        public string getdata1()
        {
            return "hello from getdata1";
        }
        public string getdata2()
        {
            return "hello from getdata2";
        }

    }
}
