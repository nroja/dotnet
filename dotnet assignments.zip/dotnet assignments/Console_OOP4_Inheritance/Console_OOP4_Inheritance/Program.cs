﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer emailid:");
            string email = Console.ReadLine();
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter customer type:");
            string type = Console.ReadLine();
            if (type == "Online")
            {
                Console.WriteLine("enter payment type:");
                string paymenttype = Console.ReadLine();
                Console.WriteLine("enter delivery address:");
                string addr = Console.ReadLine();
                Customer_Online c2 = new Customer_Online(email, name, paymenttype, addr);
                Console.WriteLine(c2.PCustomeremail + " " + c2.PCustomername + " " + c2.PPaymenttype + " " + c2.PDeliveryadd);
                Console.ReadLine();
            }
            else
            {
                Customer c1 = new Customer(email, name);
                Console.WriteLine(c1.PCustomeremail + " " + c1.PCustomername);
                Console.ReadLine();
            }
        }
    }
}
