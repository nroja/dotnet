﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collections
{
    class Student
    {

        public delegate void delleave(int ID, string Reason);
        public event delleave evtleave;

        private int StudentID;
        private string StudentName;
        private string StudentCity;
        private static int Count = 1000;
        public Student(string studentname,string studentcity)
        {
            Student.Count++;
            this.StudentID = Student.Count;
            this.StudentName = studentname;
            this.StudentCity = studentcity;
        }
        public int PStudentid { get { return this.StudentID; } }
        public string PStudentname { get { return this.StudentName; } }
        public string PStudentcity { get { return this.StudentCity; } }

        public void TakeLeave(string Reason)
        {

            if(this.evtleave!=null)
            {
                this.evtleave(this.StudentID, Reason);
            }
            Console.WriteLine("Student on leave :" + this.StudentID+",Reason is:"+Reason);
        }
    }
}
