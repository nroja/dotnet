﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OPP3_Properties
{
    class Student
    {
        private int StudentID;
        private string StudentName;
        private int StudentMarks;

        public int PStudentMarks
        {
        get 
        {
                return this.StudentMarks;
        }
        set 
        {
          if(value<0 || value>100)
           {
                    this.StudentMarks = 0;
           }
           else
           {
                    this.StudentMarks = value;
           }
           }
        }
        public int PStudentID
        {
          get
           {
                return this.StudentID;
           }
        }

        public string PStudentName
        {
           get
              {
                return this.StudentName;
              }
        }
        private static int Count = 1000;
        public Student(string studentname,int studentmarks)
        {
            Student.Count++;

            this.StudentID = Student.Count;
            this.StudentName = studentname;
            this.StudentMarks = studentmarks;
            Console.WriteLine("object constructor");
        }
        static Student()
        {
            Student.Count = 1000;
            Console.WriteLine("static constructor");
        }
    }
}
