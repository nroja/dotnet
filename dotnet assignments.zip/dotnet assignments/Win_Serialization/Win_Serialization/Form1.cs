﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Win_Serialization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_serialize_Click(object sender, EventArgs e)
        {
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_id.Text);
            p.ProductName = txt_name.Text;
            p.ProductPrice = Convert.ToInt32(txt_price.Text);
            FileStream fs = new FileStream("C:/Test/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("binary serialization done");   


        }

        private void btn_deserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/product.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter b = new BinaryFormatter();
            Product p = b.Deserialize(fs) as Product;
            fs.Close();
            txt_id.Text = p.ProductID.ToString();
            txt_name.Text = p.ProductName;
            txt_price.Text = p.ProductPrice.ToString();

        }

        private void btn_xmlserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/prod.xml", FileMode.Create, FileAccess.Write);
            Product p = new Product();
            p.ProductID = Convert.ToInt32(txt_id.Text);
            p.ProductName = txt_name.Text;
            p.ProductPrice = Convert.ToInt32(txt_price.Text);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("xml serialization done");



        }

        private void btn_xmldeserialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test/prod.xml", FileMode.Open, FileAccess.Read);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            txt_id.Text = p.ProductID.ToString();
            txt_name.Text = p.ProductName;
            txt_price.Text = p.ProductPrice.ToString();
        }
    }
}
