﻿namespace Win_Banking_Application
{
    partial class NewAccount_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.lbl_accounttype = new System.Windows.Forms.Label();
            this.cmb_accountype = new System.Windows.Forms.ComboBox();
            this.btn_newaccount = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Location = new System.Drawing.Point(111, 48);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(80, 13);
            this.lbl_customerid.TabIndex = 0;
            this.lbl_customerid.Text = "CustomerID :";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(210, 45);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(116, 20);
            this.txt_customerid.TabIndex = 1;
            this.txt_customerid.TextChanged += new System.EventHandler(this.txt_customerid_TextChanged);
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Location = new System.Drawing.Point(127, 94);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(61, 13);
            this.lbl_balance.TabIndex = 2;
            this.lbl_balance.Text = "Balance :";
            // 
            // txt_balance
            // 
            this.txt_balance.Location = new System.Drawing.Point(210, 87);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(116, 20);
            this.txt_balance.TabIndex = 3;
            // 
            // lbl_accounttype
            // 
            this.lbl_accounttype.AutoSize = true;
            this.lbl_accounttype.Location = new System.Drawing.Point(98, 139);
            this.lbl_accounttype.Name = "lbl_accounttype";
            this.lbl_accounttype.Size = new System.Drawing.Size(90, 13);
            this.lbl_accounttype.TabIndex = 4;
            this.lbl_accounttype.Text = "AccountType :";
            // 
            // cmb_accountype
            // 
            this.cmb_accountype.FormattingEnabled = true;
            this.cmb_accountype.Location = new System.Drawing.Point(210, 131);
            this.cmb_accountype.Name = "cmb_accountype";
            this.cmb_accountype.Size = new System.Drawing.Size(140, 21);
            this.cmb_accountype.TabIndex = 5;
            // 
            // btn_newaccount
            // 
            this.btn_newaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newaccount.Location = new System.Drawing.Point(101, 197);
            this.btn_newaccount.Name = "btn_newaccount";
            this.btn_newaccount.Size = new System.Drawing.Size(138, 23);
            this.btn_newaccount.TabIndex = 6;
            this.btn_newaccount.Text = "NewAccount";
            this.btn_newaccount.UseVisualStyleBackColor = true;
            this.btn_newaccount.Click += new System.EventHandler(this.btn_newaccount_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_reset.Location = new System.Drawing.Point(302, 197);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(87, 23);
            this.btn_reset.TabIndex = 7;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // NewAccount_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 374);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newaccount);
            this.Controls.Add(this.cmb_accountype);
            this.Controls.Add(this.lbl_accounttype);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customerid);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "NewAccount_form";
            this.Text = "NewAccount_form";
            this.Load += new System.EventHandler(this.NewAccount_form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.Label lbl_accounttype;
        private System.Windows.Forms.ComboBox cmb_accountype;
        private System.Windows.Forms.Button btn_newaccount;
        private System.Windows.Forms.Button btn_reset;
    }
}