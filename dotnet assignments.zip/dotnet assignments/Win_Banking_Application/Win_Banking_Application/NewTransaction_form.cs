﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application
{
    public partial class NewTransaction_form : Form
    {
        public NewTransaction_form()
        {
            InitializeComponent();
        }

        private void NewTransaction_form_Load(object sender, EventArgs e)
        {
            cmb_transtype.Items.Add("Withdraw");
            cmb_transtype.Items.Add("Deposit");
            AccountDAL dal = new AccountDAL();
            List <int> data= dal.Getaccountid(Test.customerid);
            foreach(var m in data)
            {
                cmb_accountid.Items.Add(m);
            }
        }

        private void btn_committransaction_Click(object sender, EventArgs e)
        {
            Transactions obj = new Transactions();

            obj.AccountID = Convert.ToInt32(cmb_accountid.Text);
            obj.Amount = Convert.ToInt32(txt_amount.Text);
            obj.TransactionType = cmb_transtype.Text;
            TransactionDAL dal = new TransactionDAL();
            int id = dal.AddTransaction(obj);
            AccountDAL dall = new AccountDAL();
            Accounts a = new Accounts();
            if(obj.TransactionType == "Withdraw")
            {
              

                    int data = dall.GetBalance(id);
                    MessageBox.Show("insufficient balance :" + data);
      
            }
            MessageBox.Show("transaction added:" + id);







        }
    }
}
