﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application
{
    public partial class MyTransaction_form : Form
    {
        public MyTransaction_form()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            TransactionDAL dal = new TransactionDAL();
            int id = Convert.ToInt32(cmb_newaccountid.Text);
            List<Transactions> translist = dal.ShowTransaction(id);
            dg_showtransaction.DataSource = translist;
        }

        private void MyTransaction_form_Load(object sender, EventArgs e)
        {
            AccountDAL dal = new AccountDAL();
            List<int> data1 = dal.Getaccountid(Test.customerid);
            foreach(var n in data1)
            {
                cmb_newaccountid.Items.Add(n);
            }
        }
    }
}
