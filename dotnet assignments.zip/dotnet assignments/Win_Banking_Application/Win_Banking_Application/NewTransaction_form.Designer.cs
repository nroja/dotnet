﻿namespace Win_Banking_Application
{
    partial class NewTransaction_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.lbl_type = new System.Windows.Forms.Label();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.btn_committransaction = new System.Windows.Forms.Button();
            this.cmb_transtype = new System.Windows.Forms.ComboBox();
            this.cmb_accountid = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Location = new System.Drawing.Point(132, 63);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(75, 13);
            this.lbl_accountid.TabIndex = 0;
            this.lbl_accountid.Text = "AccountID :";
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Location = new System.Drawing.Point(98, 114);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(110, 13);
            this.lbl_type.TabIndex = 1;
            this.lbl_type.Text = "TransactionType :";
            // 
            // lbl_amount
            // 
            this.lbl_amount.AutoSize = true;
            this.lbl_amount.Location = new System.Drawing.Point(145, 163);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(57, 13);
            this.lbl_amount.TabIndex = 2;
            this.lbl_amount.Text = "Amount :";
            // 
            // txt_amount
            // 
            this.txt_amount.Location = new System.Drawing.Point(232, 160);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(116, 20);
            this.txt_amount.TabIndex = 5;
            // 
            // btn_committransaction
            // 
            this.btn_committransaction.Location = new System.Drawing.Point(135, 233);
            this.btn_committransaction.Name = "btn_committransaction";
            this.btn_committransaction.Size = new System.Drawing.Size(188, 23);
            this.btn_committransaction.TabIndex = 6;
            this.btn_committransaction.Text = "Commit Transaction";
            this.btn_committransaction.UseVisualStyleBackColor = true;
            this.btn_committransaction.Click += new System.EventHandler(this.btn_committransaction_Click);
            // 
            // cmb_transtype
            // 
            this.cmb_transtype.FormattingEnabled = true;
            this.cmb_transtype.Location = new System.Drawing.Point(227, 106);
            this.cmb_transtype.Name = "cmb_transtype";
            this.cmb_transtype.Size = new System.Drawing.Size(121, 21);
            this.cmb_transtype.TabIndex = 7;
            // 
            // cmb_accountid
            // 
            this.cmb_accountid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_accountid.FormattingEnabled = true;
            this.cmb_accountid.Location = new System.Drawing.Point(227, 55);
            this.cmb_accountid.Name = "cmb_accountid";
            this.cmb_accountid.Size = new System.Drawing.Size(121, 21);
            this.cmb_accountid.TabIndex = 8;
            // 
            // NewTransaction_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 454);
            this.Controls.Add(this.cmb_accountid);
            this.Controls.Add(this.cmb_transtype);
            this.Controls.Add(this.btn_committransaction);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.lbl_amount);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.lbl_accountid);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "NewTransaction_form";
            this.Text = "NewTransaction_form";
            this.Load += new System.EventHandler(this.NewTransaction_form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.Button btn_committransaction;
        private System.Windows.Forms.ComboBox cmb_transtype;
        private System.Windows.Forms.ComboBox cmb_accountid;
    }
}