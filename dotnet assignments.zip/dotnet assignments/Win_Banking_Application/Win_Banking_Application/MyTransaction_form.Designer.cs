﻿namespace Win_Banking_Application
{
    partial class MyTransaction_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_accountid = new System.Windows.Forms.Label();
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_showtransaction = new System.Windows.Forms.DataGridView();
            this.cmb_newaccountid = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_showtransaction)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_accountid
            // 
            this.lbl_accountid.AutoSize = true;
            this.lbl_accountid.Location = new System.Drawing.Point(124, 60);
            this.lbl_accountid.Name = "lbl_accountid";
            this.lbl_accountid.Size = new System.Drawing.Size(75, 13);
            this.lbl_accountid.TabIndex = 0;
            this.lbl_accountid.Text = "AccountID :";
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(184, 125);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(87, 23);
            this.btn_show.TabIndex = 2;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_showtransaction
            // 
            this.dg_showtransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_showtransaction.Location = new System.Drawing.Point(34, 177);
            this.dg_showtransaction.Name = "dg_showtransaction";
            this.dg_showtransaction.Size = new System.Drawing.Size(568, 150);
            this.dg_showtransaction.TabIndex = 3;
            // 
            // cmb_newaccountid
            // 
            this.cmb_newaccountid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_newaccountid.FormattingEnabled = true;
            this.cmb_newaccountid.Location = new System.Drawing.Point(218, 57);
            this.cmb_newaccountid.Name = "cmb_newaccountid";
            this.cmb_newaccountid.Size = new System.Drawing.Size(121, 21);
            this.cmb_newaccountid.TabIndex = 4;
            // 
            // MyTransaction_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 408);
            this.Controls.Add(this.cmb_newaccountid);
            this.Controls.Add(this.dg_showtransaction);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.lbl_accountid);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MyTransaction_form";
            this.Text = "MyTransaction_form";
            this.Load += new System.EventHandler(this.MyTransaction_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_showtransaction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_accountid;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_showtransaction;
        private System.Windows.Forms.ComboBox cmb_newaccountid;
    }
}