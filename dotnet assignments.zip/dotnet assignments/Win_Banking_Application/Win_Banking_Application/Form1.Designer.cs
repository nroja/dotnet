﻿namespace Win_Banking_Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_loginid = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customeremail = new System.Windows.Forms.Label();
            this.lbl_customermobile = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customeremail = new System.Windows.Forms.TextBox();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.txt_gender = new System.Windows.Forms.TextBox();
            this.txt_password1 = new System.Windows.Forms.TextBox();
            this.btn_addcustomer = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_loginid
            // 
            this.lbl_loginid.AutoSize = true;
            this.lbl_loginid.Location = new System.Drawing.Point(71, 62);
            this.lbl_loginid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_loginid.Name = "lbl_loginid";
            this.lbl_loginid.Size = new System.Drawing.Size(69, 16);
            this.lbl_loginid.TabIndex = 0;
            this.lbl_loginid.Text = "LoginID :";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(57, 111);
            this.lbl_password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(84, 16);
            this.lbl_password.TabIndex = 1;
            this.lbl_password.Text = "Password :";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(148, 59);
            this.txt_loginid.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(148, 22);
            this.txt_loginid.TabIndex = 2;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(148, 108);
            this.txt_password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(148, 22);
            this.txt_password.TabIndex = 3;
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(50, 175);
            this.btn_login.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(112, 28);
            this.btn_login.TabIndex = 4;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(489, 71);
            this.lbl_customername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(122, 16);
            this.lbl_customername.TabIndex = 5;
            this.lbl_customername.Text = "CustomerName :";
            // 
            // lbl_customeremail
            // 
            this.lbl_customeremail.AutoSize = true;
            this.lbl_customeremail.Location = new System.Drawing.Point(489, 111);
            this.lbl_customeremail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_customeremail.Name = "lbl_customeremail";
            this.lbl_customeremail.Size = new System.Drawing.Size(120, 16);
            this.lbl_customeremail.TabIndex = 6;
            this.lbl_customeremail.Text = "CustomerEmail :";
            // 
            // lbl_customermobile
            // 
            this.lbl_customermobile.AutoSize = true;
            this.lbl_customermobile.Location = new System.Drawing.Point(480, 145);
            this.lbl_customermobile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_customermobile.Name = "lbl_customermobile";
            this.lbl_customermobile.Size = new System.Drawing.Size(128, 16);
            this.lbl_customermobile.TabIndex = 7;
            this.lbl_customermobile.Text = "CustomerMobile :";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Location = new System.Drawing.Point(540, 187);
            this.lbl_gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(67, 16);
            this.lbl_gender.TabIndex = 8;
            this.lbl_gender.Text = "Gender :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(528, 226);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Password :";
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(625, 68);
            this.txt_customername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(148, 22);
            this.txt_customername.TabIndex = 10;
            // 
            // txt_customeremail
            // 
            this.txt_customeremail.Location = new System.Drawing.Point(625, 107);
            this.txt_customeremail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_customeremail.Name = "txt_customeremail";
            this.txt_customeremail.Size = new System.Drawing.Size(148, 22);
            this.txt_customeremail.TabIndex = 11;
            // 
            // txt_mobile
            // 
            this.txt_mobile.Location = new System.Drawing.Point(625, 142);
            this.txt_mobile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(148, 22);
            this.txt_mobile.TabIndex = 12;
            // 
            // txt_gender
            // 
            this.txt_gender.Location = new System.Drawing.Point(625, 183);
            this.txt_gender.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_gender.Name = "txt_gender";
            this.txt_gender.Size = new System.Drawing.Size(148, 22);
            this.txt_gender.TabIndex = 13;
            // 
            // txt_password1
            // 
            this.txt_password1.Location = new System.Drawing.Point(625, 223);
            this.txt_password1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_password1.Name = "txt_password1";
            this.txt_password1.Size = new System.Drawing.Size(148, 22);
            this.txt_password1.TabIndex = 14;
            // 
            // btn_addcustomer
            // 
            this.btn_addcustomer.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_addcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addcustomer.Location = new System.Drawing.Point(567, 287);
            this.btn_addcustomer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_addcustomer.Name = "btn_addcustomer";
            this.btn_addcustomer.Size = new System.Drawing.Size(157, 28);
            this.btn_addcustomer.TabIndex = 15;
            this.btn_addcustomer.Text = "Add Customer";
            this.btn_addcustomer.UseVisualStyleBackColor = false;
            this.btn_addcustomer.Click += new System.EventHandler(this.btn_addcustomer_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(204, 175);
            this.btn_reset.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(112, 28);
            this.btn_reset.TabIndex = 16;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(964, 506);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_addcustomer);
            this.Controls.Add(this.txt_password1);
            this.Controls.Add(this.txt_gender);
            this.Controls.Add(this.txt_mobile);
            this.Controls.Add(this.txt_customeremail);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.lbl_customermobile);
            this.Controls.Add(this.lbl_customeremail);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_loginid);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_loginid;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customeremail;
        private System.Windows.Forms.Label lbl_customermobile;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customeremail;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.TextBox txt_gender;
        private System.Windows.Forms.TextBox txt_password1;
        private System.Windows.Forms.Button btn_addcustomer;
        private System.Windows.Forms.Button btn_reset;
    }
}

