﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
           txt_loginid.Text=string.Empty;
           txt_password.Text= string.Empty;

        }

        private void btn_addcustomer_Click(object sender, EventArgs e)
        {
            if(txt_customername.Text==string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if(txt_customeremail.Text==string.Empty)
            {
                MessageBox.Show("enter email");
            }
            else if(txt_mobile.Text==string.Empty)
            {
                MessageBox.Show("enter mobile no");
            }
            else if(txt_gender.Text==string.Empty)
            {
                MessageBox.Show("enter gender");
            }
            else
            {
                Customers obj = new Customers();
                obj.CustomerName = txt_customername.Text;
                obj.CustomerEmail = txt_customeremail.Text;
                obj.CustomerMobile = txt_mobile.Text;
                obj.CustomerGender = txt_gender.Text;
                obj.CustomerPassword = txt_password1.Text;
                CustomerDAL dal = new CustomerDAL();
                
                int id = dal.AddCustomer(obj);
                MessageBox.Show("customer added :" + id);

                txt_customername.Text = string.Empty;
                txt_customeremail.Text = string.Empty;
                txt_gender.Text = string.Empty;
                txt_password1.Text = string.Empty;
                txt_mobile.Text = string.Empty;



            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                MessageBox.Show("enter login id");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_loginid.Text);
                string Password = txt_password.Text;
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(ID, Password);
                if (status)
                {
                    MessageBox.Show("valid user");
                    Test.customerid = Convert.ToInt32(txt_loginid.Text);
                    Home_form hme = new Home_form();
                    hme.Show();
                }
                else
                {

                    MessageBox.Show("invalid user");
                }
            }
        }
    }
}
