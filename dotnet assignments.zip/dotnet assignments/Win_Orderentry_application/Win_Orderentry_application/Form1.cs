﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Orderentry_application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
        
       
            if (txt_orderid.Text == string.Empty)
            {
                MessageBox.Show("enter order id");
            }
            else if(txt_customername.Text == string.Empty)
            {
                MessageBox.Show("enter customer name");
            }
            else if(txt_itemid.Text == string.Empty)
            {
                MessageBox.Show("enter item id");
            }
            else if(txt_itemqty.Text == string.Empty)
            {
                MessageBox.Show("enter item quantity");
            }
            else if(txt_itemprice.Text == string.Empty)
            {
                MessageBox.Show("enter item price");
            }
            else if(txt_deliveryaddr.Text == string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if(cmb_cities.Text == string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if(rdb_cod.Checked == false && rdb_debitcard.Checked == false && rdb_paytm.Checked == false)
            {
                MessageBox.Show("select payment");
            }
            else
            {
                int id = Convert.ToInt32(txt_orderid.Text);
                string name = txt_customername.Text;
                int itemid = Convert.ToInt32(txt_itemid.Text);
                int qty = Convert.ToInt32(txt_itemqty.Text);
                int price = Convert.ToInt32(txt_itemprice.Text);
                string addr = txt_deliveryaddr.Text;
                string city = cmb_cities.Text;
                MessageBox.Show(city);
                string payment = string.Empty;
           
                if (rdb_cod.Checked)
                {
                    payment = "COD";
                }
                else if (rdb_debitcard.Checked)
                {
                    payment = "Debit card";
                }
                else
                {
                    payment = "Paytm";
                }
                Order ord = new Order(id,name,itemid,qty,price,addr,city,payment);
                int value=ord.GetOrderValue();
                MessageBox.Show("value is:" + value);
               



            }
        }

        private void cmb_cities_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_cities.Items.Add("Hyderabad");
            cmb_cities.Items.Add("Chennai");
            cmb_cities.Items.Add("Banglore");
        }
    }
}
