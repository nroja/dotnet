﻿namespace Win_Orderentry_application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.lbl_deliveryaddr = new System.Windows.Forms.Label();
            this.txt_deliveryaddr = new System.Windows.Forms.TextBox();
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rdb_cod = new System.Windows.Forms.RadioButton();
            this.rdb_debitcard = new System.Windows.Forms.RadioButton();
            this.rdb_paytm = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(57, 36);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(53, 13);
            this.lbl_orderid.TabIndex = 0;
            this.lbl_orderid.Text = "Order ID :";
            // 
            // txt_orderid
            // 
            this.txt_orderid.Location = new System.Drawing.Point(171, 29);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(100, 20);
            this.txt_orderid.TabIndex = 1;
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Location = new System.Drawing.Point(57, 72);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(88, 13);
            this.lbl_customername.TabIndex = 2;
            this.lbl_customername.Text = "Customer Name :";
            // 
            // txt_customername
            // 
            this.txt_customername.Location = new System.Drawing.Point(171, 69);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(100, 20);
            this.txt_customername.TabIndex = 3;
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Location = new System.Drawing.Point(57, 105);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(47, 13);
            this.lbl_itemid.TabIndex = 4;
            this.lbl_itemid.Text = "Item ID :";
            // 
            // txt_itemid
            // 
            this.txt_itemid.Location = new System.Drawing.Point(171, 105);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(100, 20);
            this.txt_itemid.TabIndex = 5;
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Location = new System.Drawing.Point(57, 148);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(75, 13);
            this.lbl_itemqty.TabIndex = 6;
            this.lbl_itemqty.Text = "Item Quantity :";
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Location = new System.Drawing.Point(171, 148);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(100, 20);
            this.txt_itemqty.TabIndex = 7;
            // 
            // lbl_deliveryaddr
            // 
            this.lbl_deliveryaddr.AutoSize = true;
            this.lbl_deliveryaddr.Location = new System.Drawing.Point(53, 205);
            this.lbl_deliveryaddr.Name = "lbl_deliveryaddr";
            this.lbl_deliveryaddr.Size = new System.Drawing.Size(92, 13);
            this.lbl_deliveryaddr.TabIndex = 8;
            this.lbl_deliveryaddr.Text = "Delivery Address :";
            // 
            // txt_deliveryaddr
            // 
            this.txt_deliveryaddr.Location = new System.Drawing.Point(171, 202);
            this.txt_deliveryaddr.Name = "txt_deliveryaddr";
            this.txt_deliveryaddr.Size = new System.Drawing.Size(100, 20);
            this.txt_deliveryaddr.TabIndex = 9;
            // 
            // cmb_cities
            // 
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(60, 238);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(121, 21);
            this.cmb_cities.TabIndex = 10;
            this.cmb_cities.SelectedIndexChanged += new System.EventHandler(this.cmb_cities_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 271);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Payment Option :";
            // 
            // rdb_cod
            // 
            this.rdb_cod.AutoSize = true;
            this.rdb_cod.Location = new System.Drawing.Point(186, 269);
            this.rdb_cod.Name = "rdb_cod";
            this.rdb_cod.Size = new System.Drawing.Size(48, 17);
            this.rdb_cod.TabIndex = 12;
            this.rdb_cod.TabStop = true;
            this.rdb_cod.Text = "COD";
            this.rdb_cod.UseVisualStyleBackColor = true;
            // 
            // rdb_debitcard
            // 
            this.rdb_debitcard.AutoSize = true;
            this.rdb_debitcard.Location = new System.Drawing.Point(186, 292);
            this.rdb_debitcard.Name = "rdb_debitcard";
            this.rdb_debitcard.Size = new System.Drawing.Size(75, 17);
            this.rdb_debitcard.TabIndex = 13;
            this.rdb_debitcard.TabStop = true;
            this.rdb_debitcard.Text = "Debit Card";
            this.rdb_debitcard.UseVisualStyleBackColor = true;
            // 
            // rdb_paytm
            // 
            this.rdb_paytm.AutoSize = true;
            this.rdb_paytm.Location = new System.Drawing.Point(186, 315);
            this.rdb_paytm.Name = "rdb_paytm";
            this.rdb_paytm.Size = new System.Drawing.Size(54, 17);
            this.rdb_paytm.TabIndex = 14;
            this.rdb_paytm.TabStop = true;
            this.rdb_paytm.Text = "Paytm";
            this.rdb_paytm.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Location = new System.Drawing.Point(141, 351);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(75, 29);
            this.btn_placeorder.TabIndex = 15;
            this.btn_placeorder.Text = "Place Order";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Location = new System.Drawing.Point(57, 175);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(60, 13);
            this.lbl_itemprice.TabIndex = 16;
            this.lbl_itemprice.Text = "Item Price :";
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Location = new System.Drawing.Point(171, 172);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(100, 20);
            this.txt_itemprice.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 392);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_paytm);
            this.Controls.Add(this.rdb_debitcard);
            this.Controls.Add(this.rdb_cod);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_cities);
            this.Controls.Add(this.txt_deliveryaddr);
            this.Controls.Add(this.lbl_deliveryaddr);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customername);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.Label lbl_deliveryaddr;
        private System.Windows.Forms.TextBox txt_deliveryaddr;
        private System.Windows.Forms.ComboBox cmb_cities;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdb_cod;
        private System.Windows.Forms.RadioButton rdb_debitcard;
        private System.Windows.Forms.RadioButton rdb_paytm;
        private System.Windows.Forms.Button btn_placeorder;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.TextBox txt_itemprice;
    }
}

