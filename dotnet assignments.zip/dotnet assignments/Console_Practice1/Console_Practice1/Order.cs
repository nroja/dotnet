﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice1
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public int POrderid
        {
            get { return this.OrderID; }
            set { this.OrderID = value; }
        }
        public string PCustomername
        {
            get { return this.CustomerName; }
            set { this.CustomerName = value; }
        }
        public string PItemname
        {
            get { return this.ItemName; }
            set { this.ItemName = value; }
        }
        public int PItemprice
        {
            get { return this.ItemPrice; }
            set { this.ItemPrice = value; }
        }
        public int PItemqty
        {
            get { return this.ItemQuantity; }
            set { this.ItemQuantity = value; }
        }
        private static int Count = 12;
        public Order(int orderid,string customername,string itemname,int itemprice,int itemqty)
        {
            Order.Count++;
            this.OrderID = Order.Count;
            this.CustomerName = customername;
            this.ItemName = itemname;
            this.ItemPrice = itemprice;
            this.ItemQuantity = itemqty;
        }
        public int GetOrderAmount()
        {
            return this.ItemPrice * this.ItemQuantity;
        }
    }
}
