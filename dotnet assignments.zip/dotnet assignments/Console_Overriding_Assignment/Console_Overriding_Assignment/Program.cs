﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding_Assignment
{
    class Program
    {
        static void Main(string[] args)
        { 
    
            Console.WriteLine("enter customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter item quantity:");
            int qty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item price:");
            int price = Convert.ToInt32(Console.ReadLine());
      
            Console.WriteLine("enter the type of order:");
            string type = Console.ReadLine();
            Order ord = null;
            if (type=="Order")
            {
                ord = new Order( name, qty, price);
            }
            else if(type=="Overseas")
            {
                ord = new Order_Overseas(name, qty, price);
            }
            if(ord !=null)
            {
                int value = ord.GetOrderValue();
                Console.WriteLine(value);
                Console.WriteLine(ord.POrderid + " " + ord.PCustomername + " " + ord.PItemqty + " " + ord.PItemprice+" "+value);
                Console.ReadLine();
            }


        }
    }
}
