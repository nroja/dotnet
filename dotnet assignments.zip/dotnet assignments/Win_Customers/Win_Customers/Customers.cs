﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Customers
{
    class Customers
    {
      public int Customerid { get; set; }
      public string Customername { get; set; }
      public string Customerpassword { get; set; }
      public string Customercity { get; set; }
      public string Customeraddress { get; set; }
      public string Customermobileno { get; set; }
      public string Customeremailid { get; set; }

    }
}
