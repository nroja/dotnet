﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_Login : Form
    {
        public frm_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_employeeid.Text);
            string pass = txt_password.Text;
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Login(ID, pass);
                if (status)
                {
                    MessageBox.Show("valid user");
                    frm_Home hme = new frm_Home();
                    hme.Show();
                }
                else
                {
                    MessageBox.Show("invalid user");
                }
            }
            catch(System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("sql error");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            finally
            {
                MessageBox.Show("finally block");
            }
        }

        private void btn_sqlinjection_Click(object sender, EventArgs e)
        {
            string id = txt_employeeid.Text;
            string password = txt_password.Text;
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginSqlInjection(id, password);
            if(status)
            {
                MessageBox.Show("valid user");
            }
            else
            {
                MessageBox.Show("invalid user");
            }
        }
    }
}
