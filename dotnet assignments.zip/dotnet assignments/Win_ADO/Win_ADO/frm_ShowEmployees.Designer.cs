﻿namespace Win_ADO
{
    partial class frm_ShowEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txt_employeesearch = new System.Windows.Forms.TextBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_searchall = new System.Windows.Forms.Button();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Location = new System.Drawing.Point(43, 42);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(104, 13);
            this.lbl_employeecity.TabIndex = 0;
            this.lbl_employeecity.Text = "Enter EmployeeCity :";
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Location = new System.Drawing.Point(165, 39);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(100, 20);
            this.txt_employeecity.TabIndex = 1;
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Location = new System.Drawing.Point(67, 93);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(50, 13);
            this.lbl_search.TabIndex = 2;
            this.lbl_search.Text = "Search  :";
            // 
            // txt_employeesearch
            // 
            this.txt_employeesearch.Location = new System.Drawing.Point(165, 86);
            this.txt_employeesearch.Name = "txt_employeesearch";
            this.txt_employeesearch.Size = new System.Drawing.Size(100, 20);
            this.txt_employeesearch.TabIndex = 3;
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(340, 37);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 4;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_searchall
            // 
            this.btn_searchall.Location = new System.Drawing.Point(340, 84);
            this.btn_searchall.Name = "btn_searchall";
            this.btn_searchall.Size = new System.Drawing.Size(75, 23);
            this.btn_searchall.TabIndex = 5;
            this.btn_searchall.Text = "Search(All)";
            this.btn_searchall.UseVisualStyleBackColor = true;
            this.btn_searchall.Click += new System.EventHandler(this.btn_searchall_Click);
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(60, 140);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.Size = new System.Drawing.Size(417, 150);
            this.dg_employees.TabIndex = 6;
            // 
            // frm_ShowEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 323);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.btn_searchall);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_employeesearch);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.lbl_employeecity);
            this.Name = "frm_ShowEmployees";
            this.Text = "frm_ShowEmployees";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txt_employeesearch;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_searchall;
        private System.Windows.Forms.DataGridView dg_employees;
    }
}