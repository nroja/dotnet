﻿namespace Win_ADO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.lbl_city = new System.Windows.Forms.Label();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.btn_newemployee = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(93, 46);
            this.lbl_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(113, 16);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "EmployeeName :";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(245, 42);
            this.txt_name.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(132, 22);
            this.txt_name.TabIndex = 1;
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(93, 102);
            this.lbl_city.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(98, 16);
            this.lbl_city.TabIndex = 2;
            this.lbl_city.Text = "EmployeeCity :";
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(245, 102);
            this.txt_city.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(132, 22);
            this.txt_city.TabIndex = 3;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(93, 165);
            this.lbl_password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(136, 16);
            this.lbl_password.TabIndex = 4;
            this.lbl_password.Text = "EmployeePassword :";
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(245, 161);
            this.txt_password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(132, 22);
            this.txt_password.TabIndex = 5;
            // 
            // btn_newemployee
            // 
            this.btn_newemployee.Location = new System.Drawing.Point(52, 233);
            this.btn_newemployee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_newemployee.Name = "btn_newemployee";
            this.btn_newemployee.Size = new System.Drawing.Size(100, 28);
            this.btn_newemployee.TabIndex = 6;
            this.btn_newemployee.Text = "NewEmployee";
            this.btn_newemployee.UseVisualStyleBackColor = true;
            this.btn_newemployee.Click += new System.EventHandler(this.btn_newemployee_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(259, 233);
            this.btn_reset.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(100, 28);
            this.btn_reset.TabIndex = 7;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 292);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newemployee);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_name);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button btn_newemployee;
        private System.Windows.Forms.Button btn_reset;
    }
}

