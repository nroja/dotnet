﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_Enum_Vardynamic_Using;

namespace Console_Enum_Vardynamic_Using1
{
    class Test
    {
    public void MakePayment(PaymentType t)
    {
            Console.WriteLine(t);
    }

    public static void call()
    {

    }
    }
}
