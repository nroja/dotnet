﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Implement_Interface_Concept
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(1234, "Karthik", "Banglore", 25000, "Btm layout", "dotnet project", 4, 123456, "HDFC", 27);
            Account ac = new Account();
            ac.GetEmployee(emp);
            Manager m = new Manager();
            m.GetEmployee(emp);

            HR hr1 = new HR();
            hr1.GetEmployee(emp);
            Console.ReadLine();

        }
    }
}
