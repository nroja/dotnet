﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inheritance
{
    class Customer
    {
        protected string CustomerEmailID;
        protected string CustomerName;

        public string PCustomeremail
        {
        get { return this.CustomerEmailID; }
        set { this.CustomerEmailID = value; }
        }

        public string PCustomername
        {
            get { return this.CustomerName; }
            set { this.CustomerName = value; }
        }
        public Customer(string customeremail,string customername)
        {
            this.CustomerEmailID = customeremail;
            this.CustomerName = customername;
            Console.WriteLine("customer constructor");
        }
    }
}
