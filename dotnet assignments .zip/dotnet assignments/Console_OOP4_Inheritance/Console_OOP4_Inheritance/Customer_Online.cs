﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP4_Inheritance
{
    class Customer_Online :Customer
    {
        private string PaymentType;
        private string DeliveryAddress;

        public Customer_Online(string customeremailid,string customername,string paymenttype,string deliveryadd):base(customeremailid,customername)
        {
            this.PaymentType = paymenttype;
            this.DeliveryAddress = deliveryadd;
            Console.WriteLine("customer online constructor");
        }
        public string PPaymenttype
        {
        get { return this.PaymentType; }
        }
        public string PDeliveryadd
        {
        get { return this.DeliveryAddress; }
        }
    }
}
