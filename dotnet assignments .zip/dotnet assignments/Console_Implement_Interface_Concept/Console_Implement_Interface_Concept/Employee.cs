﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Implement_Interface_Concept
{
    class Employee :IHREmp,IManagerEmp,IAccountEmp
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProjectDetails;
        private int EmployeeExperience;
        private int EmployeeAccountNumber;
        private string EmployeeAccBankName;
        private int EmployeeAge;

        public Employee(int employeeid,string employeename,string employeecity,int employeesalary,string employeeaddress
        ,string employeeproject,int employeeexp,int employeeaccnum,string employeebankname,int employeeage)
        {
            this.EmployeeID = employeeid;
            this.EmployeeName = employeename;
            this.EmployeeCity = employeecity;
            this.EmployeeSalary = employeesalary;
            this.EmployeeAddress = employeeaddress;
            this.EmployeeProjectDetails = employeeproject;
            this.EmployeeExperience = employeeexp;
            this.EmployeeAccountNumber = employeeaccnum;
            this.EmployeeAccBankName = employeebankname;
            this.EmployeeAge = employeeage;
        }

        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;
        }

        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }

        public int GetEmployeeID()
        {
            return this.EmployeeID;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExperience;
        }

        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }

        public int GetEmployeeAccountNo()
        {
            return this.EmployeeAccountNumber;
        }
    }
}
