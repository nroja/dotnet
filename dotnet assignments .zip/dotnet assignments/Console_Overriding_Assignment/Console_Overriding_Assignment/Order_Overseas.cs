﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding_Assignment
{
    class Order_Overseas:Order
    {
     public Order_Overseas(string customername,int itemqty,int itemprice)
           :base(customername,itemqty,itemprice) {

           }

           public override int GetOrderValue()
           {
            int Tax = 100;
            return this.PItemprice * PItemqty + Tax;
           }
    }
}
