﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Interface
{
    class ProductA :IProductTransport
    {
        private int ProductID;
        private string ProductName;
        public ProductA(int productid,string productname)
        {
            this.ProductID = productid;
            this.ProductName = productname;
        }
        public int GetPrice()
        {
            return 2000;
        }
        public string GetDetails()
        {
            return this.ProductID + " " + this.ProductName;
        }

        public string GetAddress()
        {
            return "Hanuman nagar,Hyderabad";
        }
    }
}
