create table tbl_Accounts
(
AccountID int identity(1000,1),
CustomerName varchar(100),
AccountBalance int
)

insert tbl_Accounts values('John',3000)
select * from tbl_Accounts

insert tbl_Accounts values('Ram',4000)
insert tbl_Accounts values('Neha',5000)