create database PathfrontADO

create table tbl_Employees
(
employeeid int identity(1000,1),
employeename varchar(50),
employeecity varchar(50),
employeepassword varchar(50),
employeeDOJ datetime
)
select * from tbl_Employees

create table tbl_Customers
(
customerid int identity(100,1) primary key,
customername varchar(50),
customerpassword varchar(50),
customercity varchar(50),
customeraddress varchar(50),
customermobileno varchar(50),
customeremailid varchar(50)
)
select * from tbl_Customers

crea


select * from tbl_Employees

create table tbl_Students
(
studentid int identity(10,1) primary key,
studentname varchar(50),
studentcity varchar(50),
studentaddress varchar(50),
studentmobileno varchar(50),
studentemailid varchar(50)
)

select * from tbl_Students
select * from tbl_Employees


create proc proc_addemployee(@name varchar(50),@city varchar(50),@password varchar(50))
as
insert tbl_Employees values(@name,@city,@password,GETDATE())
return @@identity

create proc proc_employeedetails(@id int)
as
select * from tbl_Employees where employeeid=@id

create proc proc_showemployees(@city varchar(50))
as
select * from tbl_Employees where employeecity=@city

create proc proc_searchemployees(@key varchar(50))
as
select * from tbl_Employees
where employeeid like '%'+@key+'%' or employeename like '%'+@key+'%' or employeecity like '%'+@key+'%';


create proc proc_updateemployee(@id int,@city varchar(50),@password varchar(50))
as
update tbl_Employees set employeecity=@city,employeepassword=@password where employeeid=@id
return @@rowcount

create proc proc_deleteemployee(@id int)
as
delete tbl_Employees where employeeid=@id
return @@rowcount

create proc proc_login(@id int,@password varchar(50))
as
declare @count int
select @count=count(*) from tbl_Employees where
employeeid=@id and employeepassword=@password
return @count


create proc proc_addcustomer(@name varchar(50),@password varchar(50),@city varchar(50),@address varchar(50),@mobileno varchar(50),@emailid varchar(50))
as
insert tbl_Customers values(@name,@password,@city,@address,@mobileno,@emailid)
return @@identity

create proc proc_customerdetails(@id int)
as
select * from tbl_Customers where customerid=@id

create proc proc_showcustomers(@city varchar(50))
as
select * from tbl_Customers where customercity=@city

create proc proc_search_customer(@key int)
as
select * from tbl_Customers
where customerid like '%'+@key+'%' or customercity like '%'+@key+'%' or customername like '%'+@key+'%';

create proc proc_update_customer(@id int,@address varchar(50),@mobileno varchar(50))
as
update tbl_Customers set customeraddress=@address,customermobileno=@mobileno where customerid=@id
return @@rowcount

create proc proc_deletecustomer(@id int)
as
delete tbl_Customers where customerid=@id
return @@rowcount

create proc proc_customerlogin(@id int,@password varchar(50))
as
declare @count int
select @count=count(*) from tbl_Customers
where customerid=@id and customerpassword=@password
return @count

select * from tbl_Customers
