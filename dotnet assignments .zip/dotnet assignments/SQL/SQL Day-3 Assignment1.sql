
select * from tbl_Customers


alter proc sp_add_row (@customerid int,@customername varchar(50),@customercity varchar(50),@customerdob datetime)
as
select * from tbl_Customers
begin
insert tbl_Customers values(@customerid,@customername,@customercity,@customerdob)
return @@identity
end

declare @s int
exec @s=sp_add_row 1008,'shivani','Hyderabad','11-09-1998'
select @s

select * from tbl_Customers


alter proc sp_update_row(@customerid int,@customername varchar(50),@customercity varchar(50),@customerdob varchar(50))
as
update tbl_Customers set customername=@customername,customercity=@customercity
,customerdob=@customerdob where customerid=@customerid
return 1

declare @t int
exec @t=sp_update_row 1002,'ramya','chennai','11-08-2012'
select @t

select * from tbl_CustomersInfo




alter proc sp_update_mobileno(@customerid int,@customerpassword varchar(50),@customermobileno varchar(50))
as

update tbl_CustomersInfo set customermobileno=@customermobileno 
where customerid=@customerid and customerpassword=@customerpassword
return 1


declare @new int
exec @new=sp_update_mobileno 100,'12345','9423806371'
select @new

alter proc sp_display(@customerid int)
as
select tbl_CustomersInfo.Customerid,tbl_CustomersInfo.Customername,tbl_AccountInfo.Accountid,tbl_AccountInfo.Accountbalance
from tbl_CustomersInfo join tbl_AccountInfo
on
tbl_CustomersInfo.customerid=tbl_AccountInfo.customerid 
return 1

declare @dis int
exec @dis=sp_display 101
select @dis

select * from tbl_transactioninfo
select * from tbl_accountinfo


alter Trigger trg_update_balance
on tbl_transactioninfo
for insert
as
begin 
declare @amount int
declare @accountid int
declare @type int
select @accountid=accountid,@amount=amount,@type=transactiontype from inserted
if(@type='withdraw')
begin
update tbl_accountinfo set accountbalance=accountbalance-@amount where accountid=@accountid
end
else
begin
update tbl_accountinfo set Accountbalance=Accountbalance+@amount where Accountid=@accountid
end




create view v_display
as
select tbl_CustomersInfo.Customerid,tbl_CustomersInfo.Customername,tbl_AccountInfo.Accountid,
tbl_AccountInfo.Accountbalance from tbl_CustomersInfo join tbl_AccountInfo
on
tbl_CustomersInfo.customerid=tbl_AccountInfo.Customerid


select * from v_display


select * from tbl_CustomersInfo

create proc sp_logincheck(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_CustomersInfo
where Customerid=@id and Customerpassword=@password
return @count

declare @b int
exec @b=sp_login 101,'bhagya123'
select @b

