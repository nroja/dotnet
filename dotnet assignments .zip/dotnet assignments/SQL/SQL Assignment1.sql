create database Emp_DB 

create table tbl_Employees
(
EmployeeID int,
EmployeeFName varchar(50),
EmployeeLName varchar(50),
EmployeeCity varchar(50),
EmployeeDOB datetime,
EmployeeSalary int,
EmployeeStatus varchar(50)
)
select * from tbl_Employees

alter table tbl_employees add EmployeeDpt varchar(50)

alter table tbl_employees add EmployeeDOJ datetime
select * from tbl_Employees

insert tbl_Employees values(101,'Rahul','khana','Pune','12-10-1997',25000,'working','Testing','10-12-2012')
insert tbl_Employees values(102,'Anusha','Agarwal','Chennai','10-09-1998',23000,'working','Trainee','08-10-2014')
insert tbl_Employees values(103,'Neha','Shetty','Banglore','08-22-1997',24000,'working','Testing','06-17-2015')
insert tbl_Employees values(104,'Rajesh','Reddy','Hyderabad','06-14-1992',35000,'working','HR','12-10-2014')
insert tbl_Employees values(105,'Swetha','Mamidi','Chennai','07-09-1993',28000,'Resigned','Manager','05-12-2013')
insert tbl_Employees values(106,'Virat','Kohli','Banglore','09-12-1994','30000','Resigned','HR','12-08-2010')
insert tbl_Employees values(107,'Rohith','Sharma','Kolkata','07-12-1995',25000,'working','Trainee','05-11-2012')
insert tbl_Employees values(108,'Priyanka','Kotla','Mumbai','04-26-1996',32000,'working','Software engineer','08-28-2012')
insert tbl_Employees values(109,'Mahitha','Manthri','Hyderabad','08-15-1993',23000,'Resigned','Software engineer','03-17-2013')
insert tbl_Employees values(110,'dff','dfdsf','hyd','11-02-1998','23000','working','trainee','11-11-2018')


select * from tbl_Employees

select * from tbl_Employees where employeecity='Chennai'

select * from tbl_Employees where EmployeeSalary between 25000 and 50000

select employeefname,employeeid,employeecity from tbl_Employees 

select * from tbl_Employees order by len(EmployeeFName) asc

select SUM(employeesalary) from tbl_Employees

select * from tbl_Employees

update tbl_Employees set employeecity='Pune' where employeecity='Chennai'

update tbl_Employees set EmployeeStatus='Resigned' where EmployeeID=102
select * from tbl_Employees

select * from tbl_Employees where DATEPART(mm,EmployeeDOJ)=1

select CAST(employeesalary as decimal(12,4)) from tbl_Employees

select COUNT(*) from tbl_Employees

select * from tbl_Employees where employeedoj='01-12-1997'

 select employeecity,count(*) from tbl_employees group by employeecity

 select employeeDpt,count(*) from tbl_Employees group by EmployeeDpt

 select * from tbl_Employees where DATEDIFF(yy,EmployeeDOJ,GETDATE())>5 

 select *,DATEDIFF(mm,employeedoj,getdate()) from tbl_Employees

 select employeedpt,COUNT(*) from tbl_Employees where employeesalary >50000 group by EmployeeDpt

 select * from tbl_Employees where DATEPART(mm,employeedoj)=DATEPART(mm,getdate())