USE [BankingDB]
GO

DECLARE @RC int
DECLARE @id int

-- TODO: Set parameter values here.

EXECUTE @RC = [dbo].[proc_showaccount] 
   @id=100
GO


