create database BankDB

create table tbl_CustomersInfo
(
Customerid int identity(100,1) primary key,
Customername varchar(50) not null,
Customercity varchar(50),
Customeraddress varchar(50),
Customermobileno varchar(15) unique,
CustomerPAN varchar(50) unique,
Customerpassword varchar(50)
)

insert tbl_customersinfo values('Roja','Hyderabad','Ashok nagar','9992348020','ABC12F8','12345')
insert tbl_customersinfo values('Bhagya','Banglore','Tumkur','9866368754','HG643WE','bhagya123')
insert tbl_customersinfo values('Manasa','Hyderabad','Kharmanghat','8106693560','UH892ER','manasa98')
insert tbl_CustomersInfo values('Mahitha','Pune','Shameerpet','9077234570','UHDS097','mahi12')
insert tbl_CustomersInfo values('Phani','Chennai','layout','6300657280','DH985HL','pk987')
insert tbl_CustomersInfo values('Rohan','Banglore','JP nagar','8199607809','RT87GN8','123rohan')
insert tbl_CustomersInfo values('Arjun','Mumbai','Sheer palace','7772398322','MO987RT','arjun98')

select * from tbl_CustomersInfo

create table tbl_AccountInfo
(
Accountid int identity(1000,1) primary key,
Customerid int not null foreign key references tbl_customersinfo(customerid),
Accounttype varchar(50),
Accountbalance int,
Accountopendate datetime not null,
Accountstatus varchar(50)
)

insert tbl_AccountInfo values(101,'savings',7000,GETDATE(),'open')
insert tbl_AccountInfo values(102,'current',9000,GETDATE(),'open')
insert tbl_AccountInfo values(100,'current',600,GETDATE(),'closed')
insert tbl_AccountInfo values(103,'savings',3000,GETDATE(),'blocked')
insert tbl_AccountInfo values(105,'savings',15000,GETDATE(),'open')
insert tbl_AccountInfo values(104,'current',4500,GETDATE(),'closed')
insert tbl_AccountInfo values(106,'savings',5000,GETDATE(),'open')
insert tbl_AccountInfo values(105,'current',4000,'12-09-2011','open')

select * from tbl_AccountInfo

create table tbl_TransactionInfo
(
Transactionid int identity(10000,1) primary key,
Accountid int not null foreign key references tbl_accountinfo(accountid),
Transactiontype varchar(50),
Amount int check(amount > 0),
Transactiondate datetime not null
)

insert tbl_TransactionInfo values(1001,'debit',500,GETDATE())
insert tbl_TransactionInfo values(1000,'credit',2000,GETDATE())
insert tbl_TransactionInfo values(1002,'credit',4000,GETDATE())
insert tbl_TransactionInfo values(1004,'credit',8000,GETDATE())
insert tbl_TransactionInfo values(1003,'debit',2500,GETDATE())
insert tbl_TransactionInfo values(1005,'debit',3000,GETDATE())
insert tbl_TransactionInfo values(1006,'credit',6000,GETDATE())
insert tbl_TransactionInfo values(1006,'debit',1000,GETDATE())
insert tbl_TransactionInfo values(1002,'debit',2000,'11-03-2018')


select * from tbl_TransactionInfo

select top 5* from tbl_TransactionInfo where Accountid=1001 order by Transactiondate desc

select * from tbl_TransactionInfo where accountid=105 and Transactiondate between 12-09-2012 and 11-03-2018

select * from tbl_AccountInfo where Customerid=102

select tbl_CustomersInfo.customerid,tbl_CustomersInfo.customername,tbl_CustomersInfo.Customeraddress,tbl_CustomersInfo.Customermobileno,tbl_AccountInfo.Accountid,tbl_AccountInfo.Accountbalance from tbl_CustomersInfo join tbl_AccountInfo
on
tbl_CustomersInfo.Customerid=tbl_AccountInfo.Customerid

select * from tbl_AccountInfo
select * from tbl_TransactionInfo

select tbl_AccountInfo.Accountid,tbl_AccountInfo.Accountbalance,
tbl_TransactionInfo.Transactionid,tbl_TransactionInfo.Amount,
tbl_TransactionInfo.Transactiontype from tbl_AccountInfo join tbl_TransactionInfo
on
tbl_AccountInfo.Accountid=tbl_TransactionInfo.Accountid

select * from tbl_CustomersInfo
select * from tbl_AccountInfo
select * from tbl_TransactionInfo

select tbl_CustomersInfo.Customerid,tbl_CustomersInfo.Customername,tbl_CustomersInfo.Customeraddress,tbl_CustomersInfo.Customermobileno,
tbl_AccountInfo.Accountid,tbl_AccountInfo.Accountbalance,tbl_TransactionInfo.Transactionid,tbl_TransactionInfo.Amount,tbl_TransactionInfo.Transactiontype 
from tbl_CustomersInfo join tbl_AccountInfo
on
tbl_CustomersInfo.Customerid=tbl_AccountInfo.Customerid
join tbl_TransactionInfo
on
tbl_AccountInfo.Accountid=tbl_TransactionInfo.Accountid

select * from tbl_CustomersInfo where Customerid in (
select Customerid from tbl_AccountInfo)

select * from tbl_CustomersInfo where Customerid not in (
select customerid from tbl_AccountInfo)

select * from tbl_AccountInfo where accountid in (
select accountid from tbl_TransactionInfo)

select * from tbl_AccountInfo where Accountid not in (
select Accountid from tbl_TransactionInfo)

select * from tbl_TransactionInfo