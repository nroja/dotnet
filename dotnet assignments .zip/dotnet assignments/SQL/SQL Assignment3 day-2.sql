create database OnlineFoodOrderingDB

create table tbl_Restaurants
(
Restaurantid int identity(1,1) primary key,
Restaurantname varchar(50),
Restaurantaddress varchar(50),
Restauarantcity varchar(50),
ContactNo varchar(15)
)
insert tbl_Restaurants values('Nandini','btm layout','Banglore','9984792010')
insert tbl_Restaurants values('Swagath','Nagole','Hyderabad','9866368951')
insert tbl_Restaurants values('Sampoorna','bn reddy','Hyderabad','9866772390')
insert tbl_Restaurants values('Shubam','shameerpet','Chennai','6367002388')
insert tbl_Restaurants values('punjab grill','jp nagar','Pune','9494873592')

select * from tbl_Restaurants

create table tbl_RMenuItems
(
Menuid int identity(100,1) primary key,
Restaurantid int not null foreign key references tbl_restaurants(restaurantid),
Menuname varchar(100),
Menutype varchar(100),
Menucategory varchar(100),
Menuprice int check(menuprice > 0)
)
insert tbl_RMenuItems values(2,'xyz','lunch','veg',200)
insert tbl_RMenuItems values(1,'abc','breakfast','veg',150)
insert tbl_RMenuItems values(3,'pqr','dinner','nonveg',400)
insert tbl_RMenuItems values(4,'hjj','dinner','veg',300)
insert tbl_RMenuItems values(5,'rty','breakfast','chinese',500)

select * from tbl_RMenuItems


create table tbl_Customers
(
Customerid varchar(50) primary key,
Customername varchar(50),
Customercity varchar(50),
Customerdob varchar(50),
Customergender varchar(50),
Customerpassword varchar(50)
)
insert tbl_Customers values('shiv@gmail.com','shivani','hyd','09-05-1999','F','shiv123')
insert tbl_Customers values('mahi@gmail.com','mahitha','hyd','11-06-1996','F','mahi987')
insert tbl_Customers values('arjun@gmail.com','arjun','Pune','06-05-1995','M','12345')
insert tbl_Customers values('bhagya@gmail.com','bhagya','banglore','09-04-1997','F','bhagi123')
insert tbl_Customers values('ram@gmail.com','ramu','chennai','10-06-1993','M','ram23')

select * from tbl_Customers



create table tbl_Orders
(
Orderid int identity(1000,1) primary key,
Customerid varchar(50) not null foreign key references tbl_customers(customerid),
Orderdate datetime,
Deliveryaddress varchar(50),
Orderstatus varchar(50)
)

insert tbl_Orders values('ram@gmail.com',getdate(),'jp nagar','placed')
insert tbl_Orders values('mahi@gmail.com','09-11-2012','ashok nagar','delivered')
insert tbl_Orders values('bhagya@gmail.com','04-05-2012','ram nagar','placed')
insert tbl_Orders values('ram@gmail.com','07-11-2014','jp nagar','delivered')
insert tbl_Orders values('arjun@gmail.com','03-12-2013','btm layout','not delivered')
select * from tbl_Orders
select * from tbl_RMenuItems



create table tbl_OrderMenus
(
Orderid int not null foreign key references tbl_orders(orderid),
Menuid int not null foreign key references tbl_RMenuItems(Menuid),
Menuqty int check(menuqty > 0),
Menuprice int ,
primary key(orderid,menuid)
)
insert tbl_OrderMenus values(1000,101,2,300)
insert tbl_OrderMenus values(1000,104,1,500)
insert tbl_OrderMenus values(1002,102,3,200)
insert tbl_OrderMenus values(1003,103,2,600)
insert tbl_OrderMenus values(1001,100,1,200)
select * from tbl_OrderMenus

select * from tbl_Restaurants where Restauarantcity='banglore'


select tbl_Restaurants.Restaurantid,tbl_Restaurants.Restaurantname,tbl_RMenuItems.Menuid,tbl_RMenuItems.Menuname,tbl_RMenuItems.Menuprice from tbl_Restaurants join tbl_RMenuItems
on
tbl_Restaurants.Restaurantid=tbl_RMenuItems.Restaurantid
select restauarantcity,count(*) from tbl_restaurants group by restauarantcity

select tbl_Restaurants.Restaurantid,tbl_Restaurants.Restaurantname,tbl_RMenuItems.Menuid,tbl_RMenuItems.Menuname,tbl_RMenuItems.Menuprice,tbl_Restaurants.Restauarantcity   from tbl_Restaurants join tbl_RMenuItems
on
tbl_Restaurants.Restaurantid=tbl_RMenuItems.Restaurantid




select * from tbl_Orders where customerid='ram@gmail.com'

select * from tbl_Orders
select * from tbl_OrderMenus

select tbl_Orders.Orderid,tbl_Orders.Customerid,tbl_Orders.Orderdate,tbl_OrderMenus.Menuid,tbl_OrderMenus.Menuqty,
tbl_OrderMenus.Menuprice from tbl_Orders join tbl_OrderMenus
on
tbl_Orders.Orderid=tbl_OrderMenus.Orderid

select top 5 * from tbl_Orders where customerid='ram@gmail.com' order by Orderdate desc

select * from tbl_RMenuItems order by Menuprice asc

select Restauarantcity ,count(*) from tbl_Restaurants group by Restauarantcity

select * from tbl_Customers where customerid not in (
select Customerid from tbl_Orders)



select top 1 * from tbl_RMenuItems order by Menuprice desc


select top 1 * from tbl_RMenuItems where Menuid  in
(
select top 2  Menuid from tbl_RMenuItems order by Menuprice desc
)order by menuprice asc
