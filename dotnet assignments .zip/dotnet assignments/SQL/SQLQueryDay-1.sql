create database PathfrontDB
use PathfrontDB
create table tbl_Customers
(
CustomerID int,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerDOB datetime
)
sp_help tbl_customers
select * from tbl_Customers
insert tbl_Customers values(1001,'Karthik','Hyderabad','10-22-1991')
insert tbl_Customers values(1002,'manisha','Banglore','10-11-1996')
insert tbl_Customers values(1003,'bhavani','Hyderabad','12-10-1998')
insert tbl_Customers values(1004,'radha','Chennai','09-12-1998')
insert tbl_Customers values(1005,'Mohan','Pune','11-09-1997')
insert tbl_Customers values(1006,'XYZ',null,null)
insert tbl_Customers(CustomerID,CustomerName) values(1007,'ABC')
select * from tbl_Customers
select customerid,customername from tbl_Customers
select * from tbl_Customers where customercity='Hyderabad'

update tbl_Customers set CustomerCity='Chennai' where CustomerID=1001
delete tbl_Customers where CustomerID=1001;
truncate table tbl_customers
alter table tbl_customers add CustomerEmail varchar(100)
select * from tbl_Customers
alter table tbl_customers drop column customeremail
select * from tbl_Customers
alter table tbl_customers alter column customername varchar(200)
drop table tbl_Customers
select * from tbl_customers where customercity in ('Chennai','Pune')
select * from tbl_customers where customercity is null
select * from tbl_customers where customerdob between '12-12-1990' and '12-12-2000'

select * from tbl_customers order by customerdob asc,customercity desc
select top 1 * from tbl_customers order by customerdob asc
select top 1 * from tbl_employee order by employesalary desc

select len('HELLO')
select substring('hello',1,4)
select lower('HELLO')
select upper('hello')
select left('hello',2)
select right('hello',2)
select ISNUMERIC('12a')
select CEILING(25.01)
select FLOOR(25.99)
select ROUND(253.2595,2)
select ISNULL(column_name,0)
select * from customers order by len(customername) asc
select len(customername) from tbl_customers
create table tbl_employees
(
employeeID int,
employeeName varchar(100),
employeeCity varchar(100),
employeeSalary int
)

insert tbl_employees values(101,'John','Banglore',25000)
insert tbl_employees values(102,'Raju','Pune',20000)
insert tbl_employees values(103,'Swetha','Chennai',30000)
insert tbl_employees values(104,'Rahul','Hyderabad',25000)
select * from tbl_employees
insert tbl_employees values(105,'Neha','Hyderabad',27000)

select sum(employeesalary) from tbl_employees
select MAX(employeesalary) from tbl_employees
select MIN(employeesalary) from tbl_employees
select AVG(employeesalary) from tbl_employees
select COUNT(*) from tbl_employees
select GETDATE()
select * from tbl_customers
select customerid,customername, DATEDIFF(yy,customerdob,getdate()) from tbl_customers

select customerid,customername, DATEDIFF(yy,customerdob,getdate()), DATENAME(dw,customerdob),DATEPART(dw,customerdob) from tbl_customers

select customerid,customername,DATEDIFF(yy,customerdob,getdate())
 as 'Age', DATENAME(dw,customerdob) as 'Day', DATEPART(dw,customerdob) as 'Number' from tbl_customers

 select DATEADD(mm,10,customerdob) from tbl_customers

 select CONVERT(varchar(10),employeesalary) from tbl_employees
 
 select CAST (employeesalary as decimal(12,2)) from tbl_employees

 select employeecity,count(*) from tbl_employees group by employeecity

 select employeecity,AVG(employeesalary) from tbl_employees group by employeecity

 select employeecity,MAX(employeesalary) from tbl_employees group by employeecity

 select employeecity,COUNT(*) from tbl_employees where employeesalary > 10000 group by employeecity

 select employeecity,count(*) from tbl_employees group by
 employeecity having  COUNT(*) > 1