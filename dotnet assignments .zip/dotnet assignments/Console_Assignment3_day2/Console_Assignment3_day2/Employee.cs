﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment3_day2
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private double EmployeeSalary;

        public Employee(int employeeid,string employeename,string employeecity,double employeesalary)
        {
            this.EmployeeID = employeeid;
            this.EmployeeName = employeename;
            this.EmployeeCity = employeecity;
            this.EmployeeSalary = employeesalary;


        }
         
        public double GetEmployeeSalary(int NoOfDays)
        {
             double Salary = this.EmployeeSalary/30 * NoOfDays ;
            return Salary;
        }

        public string GetDetails()
        {
            return this.EmployeeID + " " + this.EmployeeName + " " + this.EmployeeCity;
        }
    }
}
