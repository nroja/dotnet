﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment3_day2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the employeeid:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter employee name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter employee city:");
            string city = Console.ReadLine();
            Console.WriteLine("enter employee salary:");
            double salary = Convert.ToDouble(Console.ReadLine());

            Employee emp = new Employee(id, name, city, salary);
            Console.WriteLine("enter no of days:");
            int days = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("no of days:" + days);
            Double NewSalary = emp.GetEmployeeSalary(days);
            Console.WriteLine("newsalary:" + NewSalary);

            string NewDetails = emp.GetDetails();
            Console.WriteLine("details:" + NewDetails);
            Console.ReadLine();
        }
    }
}
