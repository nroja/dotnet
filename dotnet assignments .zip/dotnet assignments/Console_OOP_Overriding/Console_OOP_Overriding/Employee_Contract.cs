﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Overriding
{
    class Employee_Contract:Employee
    {
    public Employee_Contract(int employeeid,string employeename,int employeesalary)
        :base(employeeid,employeename,employeesalary)
        {

        }

        public sealed override int GetSalary(int days)
        {
            int totalsal = this.PEmployeesalary / 30 * days;
            return totalsal;
        }
    }
}
