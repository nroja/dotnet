﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_Customers
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(Customers c1)
        {
            try
            {
                SqlCommand com_add = new SqlCommand("proc_addcustomer", con);
                com_add.Parameters.AddWithValue("@name", c1.Customername);
                com_add.Parameters.AddWithValue("@password", c1.Customerpassword);
                com_add.Parameters.AddWithValue("@city", c1.Customercity);
                com_add.Parameters.AddWithValue("@address", c1.Customeraddress);
                com_add.Parameters.AddWithValue("@mobileno", c1.Customermobileno);
                com_add.Parameters.AddWithValue("@emailid", c1.Customeremailid);
                com_add.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_add.Parameters.Add(retdata);

                con.Open();
                com_add.ExecuteNonQuery();
                int ID = Convert.ToInt32(retdata.Value);
                con.Close();
                return ID;
            }
            finally
            {
         
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        public Customers Find(int ID)
        {
            SqlCommand com_search = new SqlCommand("proc_customerdetails", con);
            com_search.Parameters.AddWithValue("@id", ID);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            if (dr.Read())
            {
                Customers cus = new Customers();
                cus.Customerid = dr.GetInt32(0);
                cus.Customername = dr.GetString(1);
                cus.Customerpassword = dr.GetString(2);
                cus.Customercity = dr.GetString(3);
                cus.Customeraddress = dr.GetString(4);
                cus.Customermobileno = dr.GetString(5);
                cus.Customeremailid = dr.GetString(6);
                con.Close();
                return cus;
            }
            else
            {
                return null;
            }

        }

        public bool Update(int ID,string Address,string Mobileno)
        {
            try
            {


                SqlCommand com_update = new SqlCommand("proc_update_customer", con);
                com_update.Parameters.AddWithValue("@id", ID);
                com_update.Parameters.AddWithValue("@address", Address);
                com_update.Parameters.AddWithValue("@mobileno", Mobileno);
                com_update.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_update.Parameters.Add(retdata);
                con.Open();
                com_update.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
              
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }


        public bool Delete(int ID)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deletecustomer", con);
                com_delete.Parameters.AddWithValue("@id", ID);
                com_delete.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(retdata);
                con.Open();
                com_delete.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
               
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        public List<Customers> ShowCustomers(string city)
        {
            try
            {
                SqlCommand com_cutomer = new SqlCommand("proc_showcustomers", con);
                com_cutomer.Parameters.AddWithValue("@city", city);
                com_cutomer.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_cutomer.ExecuteReader();
                List<Customers> custlist = new List<Customers>();
                while (dr.Read())
                {
                    Customers obj = new Customers();
                    obj.Customerid = dr.GetInt32(0);
                    obj.Customername = dr.GetString(1);
                    obj.Customerpassword = dr.GetString(2);
                    obj.Customercity = dr.GetString(3);
                    obj.Customermobileno = dr.GetString(4);
                    obj.Customeremailid = dr.GetString(5);
                    custlist.Add(obj);
                }
                con.Close();
                return custlist;
            }
            finally
            {
               
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
       
        }

        public List<Customers> Searchcustomer(string Search)
        {
            try
            {


                SqlCommand com_search = new SqlCommand("proc_search_customer", con);
                com_search.Parameters.AddWithValue("@key", Search);
                com_search.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<Customers> custlist = new List<Customers>();
                while (dr.Read())
                {
                    Customers obj1 = new Customers();
                    obj1.Customerid = dr.GetInt32(0);
                    obj1.Customername = dr.GetString(1);
                    obj1.Customerpassword = dr.GetString(2);
                    obj1.Customercity = dr.GetString(3);
                    obj1.Customermobileno = dr.GetString(4);
                    obj1.Customeremailid = dr.GetString(5);
                    custlist.Add(obj1);

                }
                con.Close();
                return custlist;
            }
            finally
             {
              
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }



        }

        public bool Login(int ID,string Password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_customerlogin", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteScalar();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }

                else
                {
                    return false;
                }
            }
            finally
            {
              
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


        }



    }
}
