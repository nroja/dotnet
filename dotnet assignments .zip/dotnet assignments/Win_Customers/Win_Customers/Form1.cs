﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_id.Text = string.Empty;
            txt_name.Text = string.Empty;
            txt_city.Text = string.Empty;
            txt_address.Text = string.Empty;
            txt_password.Text = string.Empty;
            txt_mobileno.Text = string.Empty;
            txt_emailid.Text = string.Empty;
        }

        private void btn_addcustomer_Click(object sender, EventArgs e)
        {
            if(txt_name.Text==string.Empty)
            {
                MessageBox.Show("enter name");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("enter password");
            }
            else if(txt_city.Text==string.Empty)
            {
                MessageBox.Show("enter city");
            }
            else if(txt_address.Text==string.Empty)
            {
                MessageBox.Show("enter address");
            }
            else if(txt_mobileno.Text==string.Empty)
            {
                MessageBox.Show("enter mobile num");
            }

            else if(txt_emailid.Text==string.Empty)
            {
                MessageBox.Show("enter email");
            }
            else
            {
                Customers obj = new Customers();
                obj.Customername = txt_name.Text;
                obj.Customerpassword = txt_password.Text;
                obj.Customercity = txt_city.Text;
                obj.Customeraddress = txt_address.Text;
                obj.Customermobileno = txt_mobileno.Text;
                obj.Customeremailid = txt_emailid.Text;
                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("customer added:" + id);

            }


        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if(txt_id.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                CustomerDAL dal = new CustomerDAL();
                Customers cus = dal.Find(ID);
                if(cus!=null)
                {
                    txt_name.Text = cus.Customername;
                    txt_password.Text = cus.Customerpassword;
                    txt_city.Text = cus.Customercity;
                    txt_address.Text = cus.Customeraddress;
                    txt_mobileno.Text = cus.Customermobileno;
                    txt_emailid.Text = cus.Customeremailid;
                }
                else
                {
                    MessageBox.Show("not found");
                }




            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if(txt_id.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                string address = txt_address.Text;
                string mobile = txt_mobileno.Text;
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Update(ID, address, mobile);
                if(status)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("not found");
                }

            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if(txt_id.Text==string.Empty)
            {
                MessageBox.Show("enter id");
            }
            else
            {
                int ID = Convert.ToInt32(txt_id.Text);
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("deleted");
                }
                else
                {
                    MessageBox.Show("not found");
                }


            }
        }

        private void btn_search_Click_1(object sender, EventArgs e)
        {
           
        

        }
    }
}
