﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic_Collections
{
    class College
    {

        public void onLeave(int ID,string Reason)
        {
            Console.WriteLine("college class: student on leave :" + ID + "," + Reason);
        }
        private int CollegeID;
        private string CollegeName;
        public College(int collegeid,string collegename)
        {
            this.CollegeID = collegeid;
            this.CollegeName = collegename;
        }

        private List<Student> studentlist = new List<Student>();
       public void AddStudent(Student st)
       {
            Student.delleave d = new Student.delleave(this.onLeave);
            st.evtleave += d;
            studentlist.Add(st);
       }

       public Student Find(int ID)
       {
         foreach(Student s in studentlist)
          {
             if(s.PStudentid == ID)
               {
                    return s;
               }
          }
            return null;
       }

       public bool Remove(int ID)
       {
       foreach(Student s in studentlist)
       {
         if(s.PStudentid == ID)
           {
                    studentlist.Remove(s);
                    return true;
           }
       }
            return false;
       }

       public void ShowAll()
       {
        foreach(Student s in studentlist)
         {
                Console.WriteLine(s.PStudentid + " " + s.PStudentname + " " + s.PStudentcity);
         }
       }
    }
}
