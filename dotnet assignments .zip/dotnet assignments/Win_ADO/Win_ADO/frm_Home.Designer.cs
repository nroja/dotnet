﻿namespace Win_ADO
{
    partial class frm_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_addemployee = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_addemployee
            // 
            this.btn_addemployee.Location = new System.Drawing.Point(74, 96);
            this.btn_addemployee.Name = "btn_addemployee";
            this.btn_addemployee.Size = new System.Drawing.Size(75, 23);
            this.btn_addemployee.TabIndex = 0;
            this.btn_addemployee.Text = "AddEmployee";
            this.btn_addemployee.UseVisualStyleBackColor = true;
            this.btn_addemployee.Click += new System.EventHandler(this.btn_addemployee_Click);
            // 
            // btn_find
            // 
            this.btn_find.Location = new System.Drawing.Point(253, 96);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(75, 23);
            this.btn_find.TabIndex = 1;
            this.btn_find.Text = "FindEmployee";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // frm_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 261);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.btn_addemployee);
            this.Name = "frm_Home";
            this.Text = "frm_Home";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_addemployee;
        private System.Windows.Forms.Button btn_find;
    }
}