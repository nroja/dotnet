﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment4_day_2_order
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter the customer name:");
            string name = Console.ReadLine();
            Console.WriteLine("enter the item name:");
            string item = Console.ReadLine();
            Console.WriteLine("enter item price:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity:");
            int qty = Convert.ToInt32(Console.ReadLine());
            Order od = new Order(name,item,price,qty);
            int ordid = od.POrderID;
            string sname = od.PCustomerName;
            string sitem = od.PItemName;
            int ordprice = od.PItemPrice;
            int ordqty = od.PItemQuantity;
            Console.WriteLine(ordid + " " + sname + " " + sitem + " " + ordprice + " " + ordqty);
            int NewOr = od.GetOrderAmount();
            Console.WriteLine("order amount:" + NewOr);
            Console.ReadLine();
        }
    }
}
