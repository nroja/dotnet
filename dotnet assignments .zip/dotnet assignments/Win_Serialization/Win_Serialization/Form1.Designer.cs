﻿namespace Win_Serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_productid = new System.Windows.Forms.Label();
            this.lbl_productname = new System.Windows.Forms.Label();
            this.lbl_productprice = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.btn_serialize = new System.Windows.Forms.Button();
            this.btn_deserialize = new System.Windows.Forms.Button();
            this.btn_xmlserialize = new System.Windows.Forms.Button();
            this.btn_xmldeserialize = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_productid
            // 
            this.lbl_productid.AutoSize = true;
            this.lbl_productid.Location = new System.Drawing.Point(79, 49);
            this.lbl_productid.Name = "lbl_productid";
            this.lbl_productid.Size = new System.Drawing.Size(61, 13);
            this.lbl_productid.TabIndex = 0;
            this.lbl_productid.Text = "ProductID :";
            // 
            // lbl_productname
            // 
            this.lbl_productname.AutoSize = true;
            this.lbl_productname.Location = new System.Drawing.Point(62, 88);
            this.lbl_productname.Name = "lbl_productname";
            this.lbl_productname.Size = new System.Drawing.Size(78, 13);
            this.lbl_productname.TabIndex = 1;
            this.lbl_productname.Text = "ProductName :";
            // 
            // lbl_productprice
            // 
            this.lbl_productprice.AutoSize = true;
            this.lbl_productprice.Location = new System.Drawing.Point(66, 128);
            this.lbl_productprice.Name = "lbl_productprice";
            this.lbl_productprice.Size = new System.Drawing.Size(74, 13);
            this.lbl_productprice.TabIndex = 2;
            this.lbl_productprice.Text = "ProductPrice :";
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(160, 46);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(100, 20);
            this.txt_id.TabIndex = 3;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(160, 85);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 4;
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(160, 125);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(100, 20);
            this.txt_price.TabIndex = 5;
            // 
            // btn_serialize
            // 
            this.btn_serialize.Location = new System.Drawing.Point(82, 188);
            this.btn_serialize.Name = "btn_serialize";
            this.btn_serialize.Size = new System.Drawing.Size(75, 23);
            this.btn_serialize.TabIndex = 6;
            this.btn_serialize.Text = "Serialize";
            this.btn_serialize.UseVisualStyleBackColor = true;
            this.btn_serialize.Click += new System.EventHandler(this.btn_serialize_Click);
            // 
            // btn_deserialize
            // 
            this.btn_deserialize.Location = new System.Drawing.Point(221, 188);
            this.btn_deserialize.Name = "btn_deserialize";
            this.btn_deserialize.Size = new System.Drawing.Size(75, 23);
            this.btn_deserialize.TabIndex = 7;
            this.btn_deserialize.Text = "Deserialize";
            this.btn_deserialize.UseVisualStyleBackColor = true;
            this.btn_deserialize.Click += new System.EventHandler(this.btn_deserialize_Click);
            // 
            // btn_xmlserialize
            // 
            this.btn_xmlserialize.Location = new System.Drawing.Point(69, 255);
            this.btn_xmlserialize.Name = "btn_xmlserialize";
            this.btn_xmlserialize.Size = new System.Drawing.Size(121, 23);
            this.btn_xmlserialize.TabIndex = 8;
            this.btn_xmlserialize.Text = "XML Serialize";
            this.btn_xmlserialize.UseVisualStyleBackColor = true;
            this.btn_xmlserialize.Click += new System.EventHandler(this.btn_xmlserialize_Click);
            // 
            // btn_xmldeserialize
            // 
            this.btn_xmldeserialize.Location = new System.Drawing.Point(244, 255);
            this.btn_xmldeserialize.Name = "btn_xmldeserialize";
            this.btn_xmldeserialize.Size = new System.Drawing.Size(119, 23);
            this.btn_xmldeserialize.TabIndex = 9;
            this.btn_xmldeserialize.Text = "XML Deserialize";
            this.btn_xmldeserialize.UseVisualStyleBackColor = true;
            this.btn_xmldeserialize.Click += new System.EventHandler(this.btn_xmldeserialize_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 352);
            this.Controls.Add(this.btn_xmldeserialize);
            this.Controls.Add(this.btn_xmlserialize);
            this.Controls.Add(this.btn_deserialize);
            this.Controls.Add(this.btn_serialize);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.lbl_productprice);
            this.Controls.Add(this.lbl_productname);
            this.Controls.Add(this.lbl_productid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_productid;
        private System.Windows.Forms.Label lbl_productname;
        private System.Windows.Forms.Label lbl_productprice;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Button btn_serialize;
        private System.Windows.Forms.Button btn_deserialize;
        private System.Windows.Forms.Button btn_xmlserialize;
        private System.Windows.Forms.Button btn_xmldeserialize;
    }
}

