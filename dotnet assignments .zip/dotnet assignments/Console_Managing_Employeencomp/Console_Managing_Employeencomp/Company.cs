﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Managing_Employeencomp
{
    class Company
    {

        public void onLeave(int ID,string Reason)
        {
            Console.WriteLine("company class: employee on leave" + ID + "," + Reason);
        }
        private string CompanyName;
        private string CompanyAddress;

        public Company(string companyname,string companyaddress)
        {
            this.CompanyName = companyname;
            this.CompanyAddress = companyaddress;
        }

        private List<Employee> companyname = new List<Employee>();
        public void AddEmployee(Employee emp)
        {
            Employee.delleave d = new Employee.delleave(this.onLeave);
           emp.evtleave += d;

            companyname.Add(emp);
        }
        public Employee SearchEmployee(int id)
        {
        foreach(Employee e in companyname)
        {
            if(e.PEmployeeid == id)
             {
                    return e;
             }
        }
            return null;
        }

        public bool RemoveEmployee(int id)
        {
        foreach(Employee e in companyname)
        {
        if(e.PEmployeeid == id)
            {
                    companyname.Remove(e);
                    return true;
           }
        }
            return false;
        }

        public void ShowEmployess()
        {
        foreach(Employee e in companyname)
        {
                Console.WriteLine(e.PEmployeeid + " " + e.PEmployeename + " " + e.PEmployeecity);
        }
        }
    }
}
