﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment_linqand_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee { EmployeeID = 1, EmployeeName = "Raghu", EmployeeSalary = 30000, EmployeeExperience = 2, EMployeeCity="BGL" });
            emplist.Add(new Employee { EmployeeID = 2,EmployeeName="Swathi",EmployeeSalary=35000,EmployeeExperience=6,EMployeeCity="HYD"});
            emplist.Add(new Employee { EmployeeID = 3, EmployeeName = "Sreekar", EmployeeSalary = 40000, EmployeeExperience = 5, EMployeeCity = "HYD" });
            emplist.Add(new Employee { EmployeeID = 4, EmployeeName = "Arjun", EmployeeSalary = 38000, EmployeeExperience = 7, EMployeeCity = "Pune" });


            List<EmployeeLeave> empleave = new List<EmployeeLeave>();
            empleave.Add(new EmployeeLeave { LeaveID = 1001, LeaveType = "sick", Reason = "fever", EmployeeID = 2 });
            empleave.Add(new EmployeeLeave { LeaveID = 1002, LeaveType = "normal", Reason = "xyz", EmployeeID = 3 });
            empleave.Add(new EmployeeLeave { LeaveID = 1003, LeaveType = "Sick", Reason = "headache", EmployeeID = 1 });
            empleave.Add(new EmployeeLeave { LeaveID = 1004, LeaveType = "flex", Reason = "abc", EmployeeID = 4 });


            //linq-1
            var data = from e in emplist
                       where e.EmployeeExperience > 5
                       select new { EID = e.EmployeeID, EName = e.EmployeeName, ESal = e.EmployeeSalary, ECity = e.EMployeeCity };

                       foreach(var d in data)
                       {
                Console.WriteLine(d.EID + " " + d.EName + " " + d.ESal + " " + d.ECity);
                       }

            //lambda-1
            var dataorderby = emplist.Where((e) => e.EmployeeExperience > 5);
            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EMployeeCity);
            }

             //linq-2
            var saldata = from e in emplist
                          where e.EmployeeSalary > 30000
                          select new { EID = e.EmployeeName, ECity = e.EMployeeCity };

                          foreach(var s in saldata)
                          {
                Console.WriteLine(s.EID + " " + s.ECity);
                          }

            //lamba-3
            var salorder = emplist.Where((e) => e.EmployeeSalary > 30000);
            foreach(var s in salorder)
            {
                Console.WriteLine(s.EmployeeID + " " + s.EmployeeName + " " + s.EmployeeExperience);
            }
            

            //linq-3
            var citydata = from e in emplist
                           where e.EMployeeCity == "BGL"
                           select new { EID = e.EmployeeID, EName = e.EmployeeName, ESal = e.EmployeeSalary };

                           foreach(var x in citydata)
                           {
                             Console.WriteLine(x.EID + " " + x.EName + " " + x.ESal);
                           }

            //lambda-3
            var cdata = emplist.Where((e) => e.EMployeeCity == "HYD");
            foreach(var c in cdata)
            {
                Console.WriteLine(c.EmployeeID + " " + c.EmployeeName);
            }


            //ling-4

            var namedata = from e in emplist
                           where e.EmployeeName.StartsWith("A")
                           select new { EID = e.EmployeeID, ECity = e.EMployeeCity };

                           foreach(var n in namedata)
                           {
                Console.WriteLine(n.EID + " " + n.ECity);
                           }

            //lambda-4

            var ndata = emplist.Where((e) => e.EmployeeName.StartsWith("A"));
            foreach(var n in ndata)
            {
                Console.WriteLine(n.EmployeeID + " " + n.EmployeeName);
            }
            //linq-5

            var joindata = from e in emplist
                           join l in empleave
                           on e.EmployeeID equals l.EmployeeID
                           select new { EID = e.EmployeeID, EName = e.EmployeeName, LID = l.LeaveID, LReason = l.Reason };
                           foreach(var j in joindata)
                           {
                Console.WriteLine(j.EID + " " + j.EName + " " + j.LID + " " + j.LReason);
                           }
            //lambda-5

            var newjoin = emplist.Join(empleave,
            (e) => e.EmployeeID,
            (l) => l.EmployeeID,
            (e, l) => new
            {
                EID = e.EmployeeID,
                EName = e.EmployeeName,
                LID = l.LeaveID,
                LReason = l.Reason
            });

            foreach(var w in newjoin)
            {
                Console.WriteLine(w.EID + " " + w.EName + " " + w.LID + " " + w.LReason);
            }


                        Console.ReadLine();
        }
    }
}
