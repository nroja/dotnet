﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_Students
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddStudent(Student s1)
        {
            SqlCommand com_add = new SqlCommand("insert tbl_Students values(@name,@city,@address,@mobileno,@emailid)", con);
            com_add.Parameters.AddWithValue("@name", s1.StudentName);
            com_add.Parameters.AddWithValue("@city", s1.StudentCity);
            com_add.Parameters.AddWithValue("@address", s1.StudenAddress);
            com_add.Parameters.AddWithValue("@mobileno", s1.StudentMobileno);
            com_add.Parameters.AddWithValue("@emailid", s1.StudentEmailid);
            con.Open();
            com_add.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;
        }


        public Student Search(int ID)
        {
            SqlCommand com_search = new SqlCommand("select * from tbl_Students where studentid=@id", con);
            com_search.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            if (dr.Read())
            {
                Student stu = new Student();
                stu.StudentID = dr.GetInt32(0);
                stu.StudentName = dr.GetString(1);
                stu.StudentCity = dr.GetString(2);
                stu.StudenAddress = dr.GetString(3);
                stu.StudentMobileno = dr.GetString(4);
                stu.StudentEmailid = dr.GetString(5);

                con.Close();
                return stu;
            }
            else
            {
                return null;
            }

        }

        public bool Update(int ID, string Address, string Mobileno)
        {
            SqlCommand com_update = new SqlCommand("update tbl_Students set studentid=@id,studentaddress=@address,studentmobileno=@mobileno where studentid=@id", con);
            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address", Address);
            com_update.Parameters.AddWithValue("@mobileno", Mobileno);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }


        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand("delete tbl_Students where studentid=@id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

