﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            if(txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");
            }
            else if(txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.class1 obj = new Calculator.class1();
                int sum=obj.GetSum(num1,num2);
                lbl_result.Text = sum.ToString();
                
            }
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.class1 obj1 = new Calculator.class1();
                int multi = obj1.GetMultiply(num1, num2);
                lbl_result.Text = multi.ToString();
            }
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.class1 obj2 = new Calculator.class1();
                int div = obj2.GetDivide(num1, num2);
                lbl_result.Text = div.ToString();
            }
        }

        private void btn_subtract_Click(object sender, EventArgs e)
        {
            if (txt_number1.Text == string.Empty)
            {
                MessageBox.Show("enter number1");
            }
            else if (txt_number2.Text == string.Empty)
            {
                MessageBox.Show("enter number2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                Calculator.class1 obj3 = new Calculator.class1();
                int sub = obj3.GetSubtract(num1, num2);
                lbl_result.Text = sub.ToString();
            }
        }
    }
}
