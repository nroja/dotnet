﻿namespace Win_Banking_Application
{
    partial class Home_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newaccount = new System.Windows.Forms.Button();
            this.btn_myaccount = new System.Windows.Forms.Button();
            this.btn_newtransaction = new System.Windows.Forms.Button();
            this.btn_mytransaction = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newaccount
            // 
            this.btn_newaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newaccount.Location = new System.Drawing.Point(79, 80);
            this.btn_newaccount.Name = "btn_newaccount";
            this.btn_newaccount.Size = new System.Drawing.Size(112, 23);
            this.btn_newaccount.TabIndex = 0;
            this.btn_newaccount.Text = "NewAccount";
            this.btn_newaccount.UseVisualStyleBackColor = true;
            this.btn_newaccount.Click += new System.EventHandler(this.btn_newaccount_Click);
            // 
            // btn_myaccount
            // 
            this.btn_myaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_myaccount.Location = new System.Drawing.Point(263, 80);
            this.btn_myaccount.Name = "btn_myaccount";
            this.btn_myaccount.Size = new System.Drawing.Size(115, 23);
            this.btn_myaccount.TabIndex = 1;
            this.btn_myaccount.Text = "MyAccount";
            this.btn_myaccount.UseVisualStyleBackColor = true;
            this.btn_myaccount.Click += new System.EventHandler(this.btn_myaccount_Click);
            // 
            // btn_newtransaction
            // 
            this.btn_newtransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtransaction.Location = new System.Drawing.Point(79, 171);
            this.btn_newtransaction.Name = "btn_newtransaction";
            this.btn_newtransaction.Size = new System.Drawing.Size(112, 23);
            this.btn_newtransaction.TabIndex = 2;
            this.btn_newtransaction.Text = "NewTransaction";
            this.btn_newtransaction.UseVisualStyleBackColor = true;
            this.btn_newtransaction.Click += new System.EventHandler(this.btn_newtransaction_Click);
            // 
            // btn_mytransaction
            // 
            this.btn_mytransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mytransaction.Location = new System.Drawing.Point(263, 171);
            this.btn_mytransaction.Name = "btn_mytransaction";
            this.btn_mytransaction.Size = new System.Drawing.Size(115, 23);
            this.btn_mytransaction.TabIndex = 3;
            this.btn_mytransaction.Text = "MyTransactions";
            this.btn_mytransaction.UseVisualStyleBackColor = true;
            this.btn_mytransaction.Click += new System.EventHandler(this.btn_mytransaction_Click);
            // 
            // Home_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 352);
            this.Controls.Add(this.btn_mytransaction);
            this.Controls.Add(this.btn_newtransaction);
            this.Controls.Add(this.btn_myaccount);
            this.Controls.Add(this.btn_newaccount);
            this.Name = "Home_form";
            this.Text = "Home_form";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newaccount;
        private System.Windows.Forms.Button btn_myaccount;
        private System.Windows.Forms.Button btn_newtransaction;
        private System.Windows.Forms.Button btn_mytransaction;
    }
}