﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application
{
    public partial class MyAccounts_form : Form
    {
        public MyAccounts_form()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("enter customer id");
            }
            else
            {
                AccountDAL dal = new AccountDAL();
                int id = Convert.ToInt32(txt_customerid.Text);
                List<Accounts> acclist = dal.ShowAccount(id);
                dg_showaccount.DataSource = acclist;
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
         
            this.Close();
            
            
        }

        private void MyAccounts_form_Load(object sender, EventArgs e)
        {
            txt_customerid.Text = Test.customerid.ToString();
        }

        private void txt_customerid_TextChanged(object sender, EventArgs e)
        {
            txt_customerid.Enabled = false;
        }
    }
}