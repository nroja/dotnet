﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_Banking_Application
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddCustomer(Customers c)
        {
            SqlCommand com_add = new SqlCommand("proc_addcustomer", con);
            com_add.Parameters.AddWithValue("@name", c.CustomerName);
            com_add.Parameters.AddWithValue("@email", c.CustomerEmail);
            com_add.Parameters.AddWithValue("@mobile", c.CustomerMobile);
            com_add.Parameters.AddWithValue("@gender", c.CustomerPassword);
            com_add.Parameters.AddWithValue("@password", c.CustomerPassword);
            com_add.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_add.Parameters.Add(retdata);
            con.Open();
            com_add.ExecuteNonQuery();
            int ID = Convert.ToInt32(retdata.Value);
            con.Close();
            return ID;
          }

        public List<Customers> ShowCustomer(int ID)
        {
            try
            {
                SqlCommand com_show = new SqlCommand("proc_showcustomer", con);
                com_show.Parameters.AddWithValue("@id", ID);
                com_show.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_show.ExecuteReader();
                List<Customers> custlist = new List<Customers>();
                while (dr.Read())
                {
                    Customers obj = new Customers();
                    obj.CustomerID = dr.GetInt32(0);
                    obj.CustomerName = dr.GetString(1);
                    obj.CustomerEmail = dr.GetString(2);
                    obj.CustomerMobile = dr.GetString(3);
                    obj.CustomerGender = dr.GetString(4);
                    obj.CustomerPassword = dr.GetString(5);
                }
                con.Close();
                return custlist;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Login(int ID,string Password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_customerlogin", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(retdata);
                con.Open();
                com_login.ExecuteScalar();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            finally
            {
            if(con.State==ConnectionState.Open)
               {
                    con.Close();
               }
            }


        }
          




    }
}
