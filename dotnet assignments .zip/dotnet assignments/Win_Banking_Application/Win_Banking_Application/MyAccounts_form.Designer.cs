﻿namespace Win_Banking_Application
{
    partial class MyAccounts_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.btn_show = new System.Windows.Forms.Button();
            this.dg_showaccount = new System.Windows.Forms.DataGridView();
            this.btn_cancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg_showaccount)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Location = new System.Drawing.Point(102, 57);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(68, 13);
            this.lbl_customerid.TabIndex = 0;
            this.lbl_customerid.Text = "CustomerID :";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Location = new System.Drawing.Point(188, 54);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(100, 20);
            this.txt_customerid.TabIndex = 1;
            this.txt_customerid.TextChanged += new System.EventHandler(this.txt_customerid_TextChanged);
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(157, 108);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(75, 23);
            this.btn_show.TabIndex = 2;
            this.btn_show.Text = "Show";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // dg_showaccount
            // 
            this.dg_showaccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_showaccount.Location = new System.Drawing.Point(12, 177);
            this.dg_showaccount.Name = "dg_showaccount";
            this.dg_showaccount.Size = new System.Drawing.Size(508, 150);
            this.dg_showaccount.TabIndex = 3;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(314, 108);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 4;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // MyAccounts_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 397);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.dg_showaccount);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customerid);
            this.Name = "MyAccounts_form";
            this.Text = "MyAccounts_form";
            this.Load += new System.EventHandler(this.MyAccounts_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_showaccount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView dg_showaccount;
        private System.Windows.Forms.Button btn_cancel;
    }
}