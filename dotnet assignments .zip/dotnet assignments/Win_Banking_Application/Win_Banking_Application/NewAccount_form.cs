﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application
{
    public partial class NewAccount_form : Form
    {
        public NewAccount_form()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customerid.Text = string.Empty;
            txt_balance.Text = string.Empty;
           
        }

        private void NewAccount_form_Load(object sender, EventArgs e)
        {
            txt_customerid.Text = Test.customerid.ToString();

          
            cmb_accountype.Items.Add("Savings");
            cmb_accountype.Items.Add("current");
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("enter customer id");
            }
            else if (txt_balance.Text == string.Empty)
            {
                MessageBox.Show("enter balance");
            }
            else if (cmb_accountype.Text == string.Empty)
            {
                MessageBox.Show("select option");
            }
            else
            {
                Accounts obj = new Accounts();

                obj.CustomerID = Convert.ToInt32(txt_customerid.Text);
                obj.AccountBalance = Convert.ToInt32(txt_balance.Text);
                obj.AccountType = cmb_accountype.Text;

                AccountDAL dal = new AccountDAL();
                int id = dal.AddAccount(obj);
                MessageBox.Show("account added :" + id);
            }
        }

        private void txt_customerid_TextChanged(object sender, EventArgs e)
        {
            txt_customerid.Enabled = false;
        }
    }
}
