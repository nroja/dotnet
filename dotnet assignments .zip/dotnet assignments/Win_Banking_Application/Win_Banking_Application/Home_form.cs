﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application
{
    public partial class Home_form : Form
    {
        public Home_form()
        {
            InitializeComponent();
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            NewAccount_form f1 = new NewAccount_form();
            f1.Show();
            
        }

        private void btn_myaccount_Click(object sender, EventArgs e)
        {
            MyAccounts_form f2 = new MyAccounts_form();
            f2.Show();
        }

        private void btn_newtransaction_Click(object sender, EventArgs e)
        {
            NewTransaction_form f3 = new NewTransaction_form();
            f3.Show();
        }

        private void btn_mytransaction_Click(object sender, EventArgs e)
        {
            MyTransaction_form f4 = new MyTransaction_form();
            f4.Show();
        }
    }
}
